<template>
  <div class="min-h-screen flex flex-col bg-gradient-to-b from-amber-50 via-white to-amber-50">
    <!-- Navbar -->
    <nav class="sticky top-0 z-50 bg-white shadow-md border-b-4 border-amber-700">
      <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <!-- Logo & Brand -->
        <router-link to="/" class="flex items-center gap-3 hover:opacity-80 transition">
          <div class="w-10 h-10 bg-gradient-to-br from-amber-600 to-orange-600 rounded-lg flex items-center justify-center">
            <span class="text-white font-bold text-lg">🍜</span>
          </div>
          <span class="text-xl font-bold text-amber-900">LocalBowls</span>
        </router-link>

        <!-- Desktop Menu -->
        <div class="hidden md:flex items-center gap-8">
          <router-link to="/" class="text-amber-900 hover:text-orange-600 font-medium transition">Home</router-link>
          <router-link to="/menu" class="text-amber-900 hover:text-orange-600 font-medium transition">Menu</router-link>
          <router-link to="/status" class="text-amber-900 hover:text-orange-600 font-medium transition">Status</router-link>
          <router-link to="/login" class="text-amber-900 hover:text-orange-600 font-medium transition">Staff</router-link>
        </div>

        <!-- Cart Badge & Mobile Menu -->
        <div class="flex items-center gap-4">
          <!-- Cart Icon -->
          <router-link to="/keranjang" class="relative">
            <button class="relative p-2 hover:bg-amber-100 rounded-lg transition">
              <span class="text-2xl">🛒</span>
              <span v-if="cartStore.items.length > 0" class="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {{ cartStore.items.length }}
              </span>
            </button>
          </router-link>

          <!-- Mobile Menu Toggle -->
          <button @click="mobileMenuOpen = !mobileMenuOpen" class="md:hidden p-2 hover:bg-amber-100 rounded-lg transition">
            <span class="text-2xl">☰</span>
          </button>
        </div>
      </div>

      <!-- Mobile Menu -->
      <div v-if="mobileMenuOpen" class="md:hidden bg-amber-50 border-t-2 border-amber-200 py-4 px-4 flex flex-col gap-3">
        <router-link to="/" class="text-amber-900 hover:text-orange-600 font-medium transition py-2" @click="mobileMenuOpen = false">Home</router-link>
        <router-link to="/menu" class="text-amber-900 hover:text-orange-600 font-medium transition py-2" @click="mobileMenuOpen = false">Menu</router-link>
        <router-link to="/status" class="text-amber-900 hover:text-orange-600 font-medium transition py-2" @click="mobileMenuOpen = false">Status</router-link>
        <router-link to="/login" class="text-amber-900 hover:text-orange-600 font-medium transition py-2" @click="mobileMenuOpen = false">Staff</router-link>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-1">
      <router-view />
    </main>

    <!-- Footer -->
    <footer class="bg-gradient-to-r from-amber-900 to-orange-900 text-white mt-16">
      <div class="max-w-7xl mx-auto px-4 py-12">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <!-- Brand -->
          <div>
            <h3 class="text-2xl font-bold mb-4 flex items-center gap-2">
              <span>🍜</span> LocalBowls
            </h3>
            <p class="text-amber-100 text-sm">Nikmati cita rasa autentik dalam setiap gigitan.</p>
          </div>

          <!-- Quick Links -->
          <div>
            <h4 class="font-bold mb-4 text-amber-200">Menu</h4>
            <ul class="space-y-2 text-sm text-amber-100">
              <li><a href="#" class="hover:text-white transition">Makanan</a></li>
              <li><a href="#" class="hover:text-white transition">Minuman</a></li>
              <li><a href="#" class="hover:text-white transition">Promo</a></li>
            </ul>
          </div>

          <!-- Company -->
          <div>
            <h4 class="font-bold mb-4 text-amber-200">Perusahaan</h4>
            <ul class="space-y-2 text-sm text-amber-100">
              <li><a href="#" class="hover:text-white transition">Tentang Kami</a></li>
              <li><a href="#" class="hover:text-white transition">Kontak</a></li>
              <li><a href="#" class="hover:text-white transition">Kebijakan</a></li>
            </ul>
          </div>

          <!-- Contact -->
          <div>
            <h4 class="font-bold mb-4 text-amber-200">Hubungi Kami</h4>
            <ul class="space-y-2 text-sm text-amber-100">
              <li>📞 +62 274 1234567</li>
              <li>📧 info@localbowls.com</li>
              <li>📍 Yogyakarta, Indonesia</li>
            </ul>
          </div>
        </div>

        <!-- Wave SVG -->
        <svg class="w-full h-12 text-amber-800 opacity-30 mb-4" viewBox="0 0 1200 60" preserveAspectRatio="none">
          <path d="M0,30 Q300,0 600,30 T1200,30 L1200,60 L0,60 Z" fill="currentColor"></path>
        </svg>

        <!-- Bottom -->
        <div class="border-t border-amber-800 pt-4 flex flex-col md:flex-row justify-between items-center text-sm text-amber-100">
          <p>&copy; 2024 LocalBowls. All rights reserved.</p>
          <div class="flex gap-4 mt-4 md:mt-0">
            <a href="#" class="hover:text-white transition">Facebook</a>
            <a href="#" class="hover:text-white transition">Instagram</a>
            <a href="#" class="hover:text-white transition">Twitter</a>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useCartStore } from './store/cart.js'

const cartStore = useCartStore()
const mobileMenuOpen = ref(false)
</script>