<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white py-8">
    <div class="max-w-7xl mx-auto px-4">
      <!-- Header -->
      <div class="text-center mb-12">
        <h1 class="text-5xl font-bold text-amber-950 mb-4">📋 Menu Kami</h1>
        <p class="text-lg text-gray-600">Pilih hidangan favorit Anda dan nikmati kelezatannya</p>
      </div>

      <!-- Category Filter -->
      <div class="flex flex-wrap gap-3 justify-center mb-12">
        <button
          v-for="category in categories"
          :key="category"
          @click="selectedCategory = category"
          :class="[
            'px-6 py-2 rounded-full font-bold transition transform hover:scale-105',
            selectedCategory === category
              ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white'
              : 'bg-white border-2 border-amber-300 text-amber-900 hover:bg-amber-50'
          ]"
        >
          {{ category }}
        </button>
      </div>

      <!-- Menu Items Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        <div
          v-for="item in filteredMenu"
          :key="item.id"
          class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition transform hover:scale-105"
        >
          <!-- Image -->
          <div class="h-48 bg-gradient-to-br from-amber-300 to-orange-300 flex items-center justify-center text-7xl border-b-4 border-amber-200">
            {{ item.emoji }}
          </div>

          <!-- Content -->
          <div class="p-6">
            <h3 class="text-2xl font-bold text-amber-900 mb-2">{{ item.name }}</h3>
            <p class="text-gray-600 text-sm mb-4">{{ item.description }}</p>

            <!-- Info -->
            <div class="flex justify-between items-center mb-4 pb-4 border-b border-amber-100">
              <span class="text-xs bg-amber-100 text-amber-900 px-3 py-1 rounded-full">
                {{ item.category }}
              </span>
              <span class="text-xs text-gray-500">
                {{ item.prepTime }} menit
              </span>
            </div>

            <!-- Price & Action -->
            <div class="flex justify-between items-center">
              <span class="text-3xl font-bold text-orange-600">Rp {{ item.price.toLocaleString('id-ID') }}</span>
              <div class="flex gap-2">
                <button
                  @click="decrementQuantity(item.id)"
                  :disabled="quantities[item.id] === 0"
                  class="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition disabled:opacity-50"
                >
                  −
                </button>
                <span class="px-4 py-2 bg-amber-100 text-amber-900 font-bold rounded-lg min-w-12 text-center">
                  {{ quantities[item.id] || 0 }}
                </span>
                <button
                  @click="incrementQuantity(item.id)"
                  class="px-3 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Add to Cart Button -->
      <div v-if="hasItemsInCart" class="sticky bottom-4 right-4 flex justify-end">
        <button
          @click="addAllToCart"
          class="px-8 py-4 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-full font-bold shadow-lg hover:shadow-xl transition transform hover:scale-105 text-lg"
        >
          🛒 Tambah {{ totalItemsToAdd }} Item ke Keranjang
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useCartStore } from '../store/cart.js'

const cartStore = useCartStore()
const selectedCategory = ref('Semua')
const quantities = ref({})

const categories = [
  'Semua',
  'Mie & Pasta',
  'Nasi',
  'Soup',
  'Minuman',
  'Makanan Ringan'
]

const menuItems = ref([
  // Mie & Pasta
  { id: 1, name: 'Mie Kuah Spesial', category: 'Mie & Pasta', emoji: '🍜', price: 35000, description: 'Mie dengan kuah gurih, telur, dan sayuran segar', prepTime: 10 },
  { id: 2, name: 'Mie Goreng Pedas', category: 'Mie & Pasta', emoji: '🌶️', price: 38000, description: 'Mie goreng dengan bumbu pedas khas', prepTime: 8 },
  { id: 3, name: 'Spaghetti Carbonara', category: 'Mie & Pasta', emoji: '🍝', price: 45000, description: 'Spaghetti dengan saus cream dan daging', prepTime: 12 },

  // Nasi
  { id: 4, name: 'Nasi Kuning', category: 'Nasi', emoji: '🍛', price: 30000, description: 'Nasi kuning wangi dengan lauk pauk', prepTime: 12 },
  { id: 5, name: 'Nasi Goreng Telur', category: 'Nasi', emoji: '🍚', price: 32000, description: 'Nasi goreng dengan telur dan sayuran', prepTime: 10 },
  { id: 6, name: 'Nasi Biryani', category: 'Nasi', emoji: '🍱', price: 50000, description: 'Nasi biryani premium dengan daging pilihan', prepTime: 15 },

  // Soup
  { id: 7, name: 'Sup Ayam', category: 'Soup', emoji: '🍲', price: 40000, description: 'Sup hangat dengan daging ayam dan rempah', prepTime: 15 },
  { id: 8, name: 'Sup Seafood', category: 'Soup', emoji: '🦐', price: 55000, description: 'Sup lezat dengan campuran seafood segar', prepTime: 18 },
  { id: 9, name: 'Sup Sayur', category: 'Soup', emoji: '🥬', price: 25000, description: 'Sup vegetarian dengan sayuran pilihan', prepTime: 12 },

  // Minuman
  { id: 10, name: 'Jeruk Segar', category: 'Minuman', emoji: '🧃', price: 10000, description: 'Jus jeruk segar peras tangan', prepTime: 3 },
  { id: 11, name: 'Kopi Spesial', category: 'Minuman', emoji: '☕', price: 15000, description: 'Kopi arabika premium dengan latte art', prepTime: 5 },
  { id: 12, name: 'Teh Herbal', category: 'Minuman', emoji: '🍵', price: 12000, description: 'Teh herbal hangat dan menyegarkan', prepTime: 4 },

  // Makanan Ringan
  { id: 13, name: 'Gorengan Tahu', category: 'Makanan Ringan', emoji: '🍟', price: 15000, description: 'Tahu goreng crispy dengan sambal', prepTime: 8 },
  { id: 14, name: 'Lumpia Isi', category: 'Makanan Ringan', emoji: '🥟', price: 20000, description: 'Lumpia goreng dengan isi daging dan sayuran', prepTime: 7 },
  { id: 15, name: 'Perkedel Kentang', category: 'Makanan Ringan', emoji: '🥔', price: 18000, description: 'Perkedel goreng enak dan empuk', prepTime: 6 }
])

const filteredMenu = computed(() => {
  if (selectedCategory.value === 'Semua') {
    return menuItems.value
  }
  return menuItems.value.filter(item => item.category === selectedCategory.value)
})

const hasItemsInCart = computed(() => {
  return Object.values(quantities.value).some(q => q > 0)
})

const totalItemsToAdd = computed(() => {
  return Object.values(quantities.value).reduce((sum, q) => sum + q, 0)
})

const incrementQuantity = (itemId) => {
  quantities.value[itemId] = (quantities.value[itemId] || 0) + 1
}

const decrementQuantity = (itemId) => {
  if (quantities.value[itemId] > 0) {
    quantities.value[itemId]--
  }
}

const addAllToCart = () => {
  for (const [itemId, quantity] of Object.entries(quantities.value)) {
    if (quantity > 0) {
      const item = menuItems.value.find(m => m.id === parseInt(itemId))
      if (item) {
        cartStore.addItem({
          ...item,
          quantity
        })
      }
    }
  }
  quantities.value = {}
  alert('Item berhasil ditambahkan ke keranjang!')
}

onMounted(() => {
  document.title = 'Menu - LocalBowls'
})
</script>