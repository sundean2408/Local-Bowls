<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white py-8">
    <div class="max-w-4xl mx-auto px-4">
      <!-- Header -->
      <div class="mb-8">
        <h1 class="text-4xl font-bold text-amber-950">📍 Status Pesanan</h1>
        <p class="text-gray-600 mt-2">Pantau status pesanan Anda secara real-time</p>
      </div>

      <!-- Order ID Input Card -->
      <div class="bg-white rounded-2xl p-8 shadow-md mb-8">
        <h2 class="text-2xl font-bold text-amber-900 mb-4">🔍 Cari Pesanan</h2>
        <div class="flex gap-4">
          <input
            v-model="searchOrderId"
            type="text"
            placeholder="Masukkan No. Pesanan (contoh: 123456)"
            class="flex-1 px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition"
          />
          <button
            @click="searchOrder"
            class="px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition"
          >
            Cari
          </button>
        </div>
      </div>

      <!-- Current Order Display -->
      <div v-if="currentOrder" class="space-y-8">
        <!-- Order Card -->
        <div class="bg-white rounded-2xl p-8 shadow-lg border-2 border-amber-200">
          <!-- Header Info -->
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 pb-8 border-b-2 border-amber-100">
            <div>
              <p class="text-sm text-gray-600 mb-1">No. Pesanan</p>
              <p class="text-3xl font-bold text-orange-600">#{{ currentOrder.orderId }}</p>
            </div>
            <div>
              <p class="text-sm text-gray-600 mb-1">Waktu Pemesanan</p>
              <p class="text-lg font-bold text-amber-900">{{ formatTime(currentOrder.timestamp) }}</p>
            </div>
            <div>
              <p class="text-sm text-gray-600 mb-1">Total Pembayaran</p>
              <p class="text-2xl font-bold text-green-600">Rp {{ currentOrder.total.toLocaleString('id-ID') }}</p>
            </div>
          </div>

          <!-- Customer Info -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 pb-8 border-b-2 border-amber-100">
            <div>
              <p class="text-sm text-gray-600 mb-2">👤 Nama Pelanggan</p>
              <p class="text-lg font-bold text-amber-900">{{ currentOrder.customerInfo.name }}</p>
            </div>
            <div>
              <p class="text-sm text-gray-600 mb-2">📞 Nomor Telepon</p>
              <p class="text-lg font-bold text-amber-900">{{ currentOrder.customerInfo.phone }}</p>
            </div>
            <div>
              <p class="text-sm text-gray-600 mb-2">🪑 Nomor Meja</p>
              <p class="text-lg font-bold text-amber-900">{{ currentOrder.customerInfo.table }}</p>
            </div>
            <div>
              <p class="text-sm text-gray-600 mb-2">💳 Metode Pembayaran</p>
              <p class="text-lg font-bold text-amber-900">{{ paymentMethodLabel(currentOrder.customerInfo.paymentMethod) }}</p>
            </div>
          </div>

          <!-- Items List -->
          <div class="mb-8 pb-8 border-b-2 border-amber-100">
            <p class="text-sm text-gray-600 mb-4">📋 Item Pesanan</p>
            <div class="space-y-2">
              <div v-for="item in currentOrder.items" :key="item.cartItemId" class="flex justify-between text-amber-900">
                <span>{{ item.quantity }}x {{ item.name }}</span>
                <span class="font-bold">Rp {{ (item.price * item.quantity).toLocaleString('id-ID') }}</span>
              </div>
            </div>
          </div>

          <!-- Notes -->
          <div v-if="currentOrder.customerInfo.notes" class="bg-amber-50 p-4 rounded-lg border-l-4 border-amber-400">
            <p class="text-sm text-gray-600 mb-2">📝 Catatan Khusus</p>
            <p class="text-amber-900 font-semibold">{{ currentOrder.customerInfo.notes }}</p>
          </div>
        </div>

        <!-- Status Timeline -->
        <div class="bg-white rounded-2xl p-8 shadow-lg">
          <h2 class="text-2xl font-bold text-amber-900 mb-8">⏱️ Progress Pesanan</h2>

          <div class="space-y-4">
            <!-- Timeline Item 1: Order Confirmed -->
            <div class="flex gap-4 items-start">
              <div class="relative flex flex-col items-center">
                <div :class="['w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg', isStageComplete('confirmed') ? 'bg-green-500 text-white' : 'bg-amber-300 text-amber-900']">
                  ✓
                </div>
                <div class="w-1 h-16 bg-amber-200 mt-2" v-if="true"></div>
              </div>
              <div class="pt-1">
                <h3 class="font-bold text-amber-900">Pesanan Dikonfirmasi</h3>
                <p class="text-sm text-gray-600">Pesanan Anda telah diterima dan dikonfirmasi</p>
                <p class="text-xs text-gray-500 mt-1">{{ formatTime(currentOrder.timestamp) }}</p>
              </div>
            </div>

            <!-- Timeline Item 2: Preparing -->
            <div class="flex gap-4 items-start">
              <div class="relative flex flex-col items-center">
                <div :class="['w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg', isStageComplete('preparing') ? 'bg-green-500 text-white' : 'bg-amber-300 text-amber-900']">
                  {{ isStageComplete('preparing') ? '✓' : '2' }}
                </div>
                <div class="w-1 h-16 bg-amber-200 mt-2" v-if="true"></div>
              </div>
              <div class="pt-1">
                <h3 class="font-bold text-amber-900">Sedang Dimasak</h3>
                <p class="text-sm text-gray-600">Chef kami sedang menyiapkan pesanan Anda</p>
                <p class="text-xs text-gray-500 mt-1">{{ formatTime(addMinutesToDate(currentOrder.timestamp, 2)) }}</p>
              </div>
            </div>

            <!-- Timeline Item 3: Ready -->
            <div class="flex gap-4 items-start">
              <div class="relative flex flex-col items-center">
                <div :class="['w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg', isStageComplete('ready') ? 'bg-green-500 text-white' : 'bg-amber-300 text-amber-900']">
                  {{ isStageComplete('ready') ? '✓' : '3' }}
                </div>
                <div class="w-1 h-16 bg-amber-200 mt-2" v-if="true"></div>
              </div>
              <div class="pt-1">
                <h3 class="font-bold text-amber-900">Siap Disajikan</h3>
                <p class="text-sm text-gray-600">Pesanan Anda sudah siap dan akan segera disajikan</p>
                <p class="text-xs text-gray-500 mt-1">{{ formatTime(addMinutesToDate(currentOrder.timestamp, 15)) }}</p>
              </div>
            </div>

            <!-- Timeline Item 4: Completed -->
            <div class="flex gap-4 items-start">
              <div :class="['w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg', isStageComplete('completed') ? 'bg-green-500 text-white' : 'bg-gray-300 text-white']">
                {{ isStageComplete('completed') ? '✓' : '4' }}
              </div>
              <div class="pt-1">
                <h3 class="font-bold" :class="isStageComplete('completed') ? 'text-green-600' : 'text-gray-600'">Selesai</h3>
                <p class="text-sm text-gray-600">Terima kasih telah memesan di LocalBowls!</p>
                <p class="text-xs text-gray-500 mt-1" v-if="isStageComplete('completed')">{{ formatTime(addMinutesToDate(currentOrder.timestamp, 20)) }}</p>
              </div>
            </div>
          </div>

          <!-- Progress Bar -->
          <div class="mt-8 pt-8 border-t-2 border-amber-100">
            <div class="flex justify-between items-center mb-4">
              <p class="font-bold text-amber-900">Progress</p>
              <p class="text-sm text-gray-600">{{ progressPercentage }}%</p>
            </div>
            <div class="w-full h-3 bg-amber-100 rounded-full overflow-hidden">
              <div class="h-full bg-gradient-to-r from-amber-600 to-orange-600 rounded-full transition-all" :style="{ width: progressPercentage + '%' }"></div>
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex flex-col sm:flex-row gap-4">
          <router-link to="/menu" class="px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold text-center hover:shadow-lg transition flex-1">
            Pesan Lagi 🍜
          </router-link>
          <button @click="printReceipt" class="px-8 py-3 border-2 border-amber-300 text-amber-900 rounded-lg font-bold hover:bg-amber-50 transition flex-1">
            Cetak Struk 🖨️
          </button>
        </div>
      </div>

      <!-- Empty State -->
      <div v-else class="bg-white rounded-2xl p-12 text-center">
        <div class="text-6xl mb-4">📭</div>
        <h2 class="text-2xl font-bold text-amber-900 mb-4">Belum Ada Pesanan</h2>
        <p class="text-gray-600 mb-8">Mulai pesan makanan lezat LocalBowls sekarang!</p>
        <router-link to="/menu" class="inline-block px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition">
          Mulai Pesan →
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const searchOrderId = ref('')
const currentOrder = ref(null)
const orderStage = ref('confirmed') // confirmed, preparing, ready, completed

// Demo orders for testing
const demoOrders = {
  123456: {
    orderId: 123456,
    items: [
      { cartItemId: 1, name: 'Mie Kuah Spesial', quantity: 2, price: 35000, emoji: '🍜' },
      { cartItemId: 2, name: 'Jeruk Segar', quantity: 1, price: 10000, emoji: '🧃' }
    ],
    total: 80000,
    timestamp: new Date(Date.now() - 5 * 60000),
    customerInfo: {
      name: 'Budi Santoso',
      phone: '081234567890',
      table: 'A-05',
      notes: 'Tanpa pedas',
      paymentMethod: 'cash'
    }
  }
}

const searchOrder = () => {
  const order = demoOrders[searchOrderId.value]
  if (order) {
    currentOrder.value = order
    // Simulate progress based on time
    const elapsedMinutes = Math.floor((Date.now() - order.timestamp.getTime()) / 60000)
    if (elapsedMinutes < 2) {
      orderStage.value = 'confirmed'
    } else if (elapsedMinutes < 15) {
      orderStage.value = 'preparing'
    } else if (elapsedMinutes < 20) {
      orderStage.value = 'ready'
    } else {
      orderStage.value = 'completed'
    }
  } else {
    alert('Pesanan tidak ditemukan!')
    currentOrder.value = null
  }
}

const isStageComplete = (stage) => {
  const stages = ['confirmed', 'preparing', 'ready', 'completed']
  return stages.indexOf(stage) <= stages.indexOf(orderStage.value)
}

const progressPercentage = computed(() => {
  const stages = { confirmed: 25, preparing: 50, ready: 75, completed: 100 }
  return stages[orderStage.value] || 0
})

const formatTime = (date) => {
  return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
}

const addMinutesToDate = (date, minutes) => {
  return new Date(date.getTime() + minutes * 60000)
}

const paymentMethodLabel = (method) => {
  const labels = {
    cash: '💵 Tunai',
    card: '🏧 Kartu',
    ewallet: '📱 E-Wallet'
  }
  return labels[method] || method
}

const printReceipt = () => {
  alert('Fungsi cetak sedang dalam pengembangan')
}

onMounted(() => {
  document.title = 'Status Pesanan - LocalBowls'
  
  // Auto-load order from URL if available
  const orderId = route.query.orderId
  if (orderId) {
    searchOrderId.value = orderId
    searchOrder()
  }
})
</script>