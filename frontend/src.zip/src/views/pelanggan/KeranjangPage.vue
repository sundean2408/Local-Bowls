<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white py-8">
    <div class="max-w-6xl mx-auto px-4">
      <!-- Header -->
      <div class="mb-8">
        <h1 class="text-4xl font-bold text-amber-950">🛒 Keranjang Belanja</h1>
        <p class="text-gray-600 mt-2">{{ cartStore.items.length }} item di keranjang Anda</p>
      </div>

      <!-- Cart Content -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Cart Items -->
        <div class="lg:col-span-2">
          <div v-if="cartStore.items.length === 0" class="bg-white rounded-2xl p-12 text-center">
            <div class="text-6xl mb-4">🛒</div>
            <h2 class="text-2xl font-bold text-amber-900 mb-4">Keranjang Anda Kosong</h2>
            <p class="text-gray-600 mb-8">Mulai pesan makanan lezat sekarang!</p>
            <router-link to="/menu" class="inline-block px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition">
              Belanja Sekarang →
            </router-link>
          </div>

          <div v-else class="space-y-4">
            <div
              v-for="item in cartStore.items"
              :key="item.cartItemId"
              class="bg-white rounded-2xl p-6 flex items-start justify-between shadow-md hover:shadow-lg transition"
            >
              <!-- Item Info -->
              <div class="flex gap-4 flex-1">
                <div class="text-5xl">{{ item.emoji }}</div>
                <div class="flex-1">
                  <h3 class="text-xl font-bold text-amber-900">{{ item.name }}</h3>
                  <p class="text-gray-600 text-sm">{{ item.description }}</p>
                  <p class="text-orange-600 font-bold mt-2">Rp {{ item.price.toLocaleString('id-ID') }}/item</p>
                </div>
              </div>

              <!-- Quantity Controls -->
              <div class="flex items-center gap-3 bg-amber-50 px-4 py-2 rounded-lg">
                <button
                  @click="cartStore.updateQuantity(item.cartItemId, item.quantity - 1)"
                  class="px-2 py-1 text-gray-700 hover:bg-white rounded transition"
                >
                  −
                </button>
                <span class="font-bold text-amber-900 min-w-8 text-center">{{ item.quantity }}</span>
                <button
                  @click="cartStore.updateQuantity(item.cartItemId, item.quantity + 1)"
                  class="px-2 py-1 text-orange-600 hover:bg-white rounded transition"
                >
                  +
                </button>
              </div>

              <!-- Subtotal & Delete -->
              <div class="flex flex-col items-end gap-3 ml-4">
                <div class="text-right">
                  <p class="text-sm text-gray-500">Subtotal</p>
                  <p class="text-2xl font-bold text-orange-600">Rp {{ (item.price * item.quantity).toLocaleString('id-ID') }}</p>
                </div>
                <button
                  @click="cartStore.removeItem(item.cartItemId)"
                  class="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition font-bold"
                >
                  🗑️ Hapus
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Order Summary Sidebar -->
        <div v-if="cartStore.items.length > 0" class="sticky top-20 h-fit">
          <div class="bg-white rounded-2xl p-8 shadow-lg border-2 border-amber-200">
            <h2 class="text-2xl font-bold text-amber-900 mb-6">📊 Ringkasan Pesanan</h2>

            <!-- Summary Items -->
            <div class="space-y-3 mb-6 pb-6 border-b-2 border-amber-100">
              <div class="flex justify-between text-gray-600">
                <span>Subtotal ({{ cartStore.items.length }} item):</span>
                <span>Rp {{ cartStore.total.toLocaleString('id-ID') }}</span>
              </div>
              <div class="flex justify-between text-gray-600">
                <span>Biaya Layanan:</span>
                <span class="text-green-600 font-bold">Gratis</span>
              </div>
              <div class="flex justify-between text-gray-600">
                <span>Ongkir:</span>
                <span>Rp 10.000</span>
              </div>
            </div>

            <!-- Total -->
            <div class="bg-gradient-to-r from-amber-100 to-orange-100 p-4 rounded-xl mb-6">
              <div class="flex justify-between items-center">
                <span class="text-lg font-bold text-amber-900">Total Bayar:</span>
                <span class="text-3xl font-bold text-orange-600">
                  Rp {{ (cartStore.total + 10000).toLocaleString('id-ID') }}
                </span>
              </div>
            </div>

            <!-- Buttons -->
            <div class="space-y-3">
              <router-link to="/konfirmasi" class="block w-full py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold text-center hover:shadow-lg transition transform hover:scale-105">
                Lanjut ke Checkout ✓
              </router-link>
              <router-link to="/menu" class="block w-full py-3 border-2 border-amber-300 text-amber-900 rounded-lg font-bold text-center hover:bg-amber-50 transition">
                Tambah Pesanan
              </router-link>
            </div>

            <!-- Clear Cart -->
            <button
              @click="cartStore.clearCart"
              class="w-full mt-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition font-bold text-sm"
            >
              🗑️ Kosongkan Keranjang
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useCartStore } from '../store/cart.js'

const cartStore = useCartStore()

onMounted(() => {
  document.title = 'Keranjang Belanja - LocalBowls'
})
</script>