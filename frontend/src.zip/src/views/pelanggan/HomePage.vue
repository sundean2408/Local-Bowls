<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white">
    <!-- Hero Section -->
    <section class="relative py-16 md:py-24 bg-gradient-to-r from-amber-100 via-yellow-50 to-orange-100 overflow-hidden">
      <div class="absolute inset-0 opacity-20">
        <div class="absolute top-10 left-10 w-40 h-40 bg-amber-300 rounded-full mix-blend-multiply filter blur-3xl"></div>
        <div class="absolute bottom-10 right-10 w-40 h-40 bg-orange-300 rounded-full mix-blend-multiply filter blur-3xl"></div>
      </div>

      <div class="max-w-7xl mx-auto px-4 relative z-10">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <!-- Left Content -->
          <div class="text-center md:text-left">
            <h1 class="text-5xl md:text-6xl font-bold text-amber-950 mb-4 leading-tight">
              Nikmati Cita Rasa <span class="text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600">Autentik</span>
            </h1>
            <p class="text-lg text-amber-800 mb-8 opacity-90">
              Setiap hidangan kami dibuat dengan bahan-bahan pilihan dan resep tradisional. Pesan sekarang dan rasakan kelezatannya!
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <router-link to="/menu" class="px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg hover:scale-105 transition transform">
                Pesan Sekarang 🍜
              </router-link>
              <button class="px-8 py-3 border-2 border-amber-600 text-amber-900 rounded-lg font-bold hover:bg-amber-100 transition">
                Pelajari Lebih Lanjut
              </button>
            </div>
          </div>

          <!-- Right - Image -->
          <div class="flex justify-center">
            <div class="relative w-64 h-64 md:w-80 md:h-80">
              <div class="absolute inset-0 bg-gradient-to-br from-amber-400 to-orange-400 rounded-3xl transform rotate-6 opacity-20"></div>
              <div class="absolute inset-0 bg-white rounded-3xl flex items-center justify-center text-8xl shadow-2xl">
                🍜
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="py-16 max-w-7xl mx-auto px-4">
      <h2 class="text-4xl font-bold text-center text-amber-950 mb-12">Mengapa Memilih Kami?</h2>
      
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <!-- Feature 1 -->
        <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl hover:scale-105 transition transform">
          <div class="text-6xl mb-4">⚡</div>
          <h3 class="text-2xl font-bold text-amber-900 mb-3">Cepat & Tepat Waktu</h3>
          <p class="text-gray-600">Pesanan Anda akan siap dalam waktu yang telah ditentukan. Kami berkomitmen untuk kecepatan dan ketepatan waktu.</p>
        </div>

        <!-- Feature 2 -->
        <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl hover:scale-105 transition transform">
          <div class="text-6xl mb-4">🎨</div>
          <h3 class="text-2xl font-bold text-amber-900 mb-3">Presentasi Istimewa</h3>
          <p class="text-gray-600">Setiap hidangan kami disajikan dengan presentasi yang indah dan menarik. Mata juga menikmati hidangan!</p>
        </div>

        <!-- Feature 3 -->
        <div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl hover:scale-105 transition transform">
          <div class="text-6xl mb-4">💯</div>
          <h3 class="text-2xl font-bold text-amber-900 mb-3">Kualitas Terjamin</h3>
          <p class="text-gray-600">Bahan berkualitas premium dan resep terbaik adalah standar kami. Kepuasan Anda adalah prioritas kami.</p>
        </div>
      </div>
    </section>

    <!-- Popular Menu Preview -->
    <section class="py-16 bg-gradient-to-r from-amber-50 to-orange-50">
      <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-4xl font-bold text-center text-amber-950 mb-12">Menu Pilihan</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <!-- Menu Card 1 -->
          <div class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition transform hover:scale-105">
            <div class="h-48 bg-gradient-to-br from-amber-300 to-orange-300 flex items-center justify-center text-7xl">
              🍜
            </div>
            <div class="p-6">
              <h3 class="text-2xl font-bold text-amber-900 mb-2">Mie Kuah Spesial</h3>
              <p class="text-gray-600 mb-4">Mie dengan kuah gurih yang nikmat, topping telur dan sayuran segar.</p>
              <div class="flex justify-between items-center">
                <span class="text-2xl font-bold text-orange-600">Rp 35.000</span>
                <button class="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition">
                  +
                </button>
              </div>
            </div>
          </div>

          <!-- Menu Card 2 -->
          <div class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition transform hover:scale-105">
            <div class="h-48 bg-gradient-to-br from-amber-300 to-orange-300 flex items-center justify-center text-7xl">
              🍲
            </div>
            <div class="p-6">
              <h3 class="text-2xl font-bold text-amber-900 mb-2">Soup Lezat</h3>
              <p class="text-gray-600 mb-4">Sup hangat dengan daging pilihan dan rempah-rempah tradisional.</p>
              <div class="flex justify-between items-center">
                <span class="text-2xl font-bold text-orange-600">Rp 40.000</span>
                <button class="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition">
                  +
                </button>
              </div>
            </div>
          </div>

          <!-- Menu Card 3 -->
          <div class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition transform hover:scale-105">
            <div class="h-48 bg-gradient-to-br from-amber-300 to-orange-300 flex items-center justify-center text-7xl">
              🍛
            </div>
            <div class="p-6">
              <h3 class="text-2xl font-bold text-amber-900 mb-2">Nasi Kuning</h3>
              <p class="text-gray-600 mb-4">Nasi kuning wangi dengan lauk pauk pilihan dan sambal pedas.</p>
              <div class="flex justify-between items-center">
                <span class="text-2xl font-bold text-orange-600">Rp 30.000</span>
                <button class="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition">
                  +
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="text-center">
          <router-link to="/menu" class="inline-block px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition">
            Lihat Semua Menu →
          </router-link>
        </div>
      </div>
    </section>

    <!-- Call to Action -->
    <section class="py-16 bg-gradient-to-r from-amber-900 to-orange-900 text-white">
      <div class="max-w-4xl mx-auto px-4 text-center">
        <h2 class="text-4xl font-bold mb-4">Siap untuk Memesan?</h2>
        <p class="text-xl mb-8 text-amber-100">Jangan lewatkan kesempatan untuk mencicipi kelezatan kami hari ini!</p>
        <router-link to="/menu" class="inline-block px-8 py-3 bg-white text-amber-900 rounded-lg font-bold hover:bg-amber-100 transition">
          Mulai Pesan Sekarang
        </router-link>
      </div>
    </section>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'

onMounted(() => {
  document.title = 'LocalBowls - Pesan Makanan Lezat'
})
</script>