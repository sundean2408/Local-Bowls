<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white py-8">
    <div class="max-w-6xl mx-auto px-4">
      <!-- Header -->
      <div class="mb-8">
        <h1 class="text-4xl font-bold text-amber-950">✓ Konfirmasi Pesanan</h1>
        <p class="text-gray-600 mt-2">Isi data Anda untuk menyelesaikan pesanan</p>
      </div>

      <!-- Content Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Form Section -->
        <div class="lg:col-span-2">
          <form @submit.prevent="submitOrder" class="space-y-6">
            <!-- Customer Info Card -->
            <div class="bg-white rounded-2xl p-8 shadow-md">
              <h2 class="text-2xl font-bold text-amber-900 mb-6">👤 Data Pelanggan</h2>

              <div class="space-y-4">
                <!-- Name -->
                <div>
                  <label class="block text-amber-900 font-bold mb-2">Nama Lengkap</label>
                  <input
                    v-model="formData.name"
                    type="text"
                    placeholder="Masukkan nama Anda"
                    required
                    class="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition"
                  />
                </div>

                <!-- Phone -->
                <div>
                  <label class="block text-amber-900 font-bold mb-2">Nomor Telepon</label>
                  <input
                    v-model="formData.phone"
                    type="tel"
                    placeholder="Masukkan nomor telepon Anda"
                    required
                    class="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition"
                  />
                </div>

                <!-- Table Number -->
                <div>
                  <label class="block text-amber-900 font-bold mb-2">Nomor Meja</label>
                  <input
                    v-model="formData.table"
                    type="text"
                    placeholder="Contoh: A-05"
                    required
                    class="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition"
                  />
                </div>

                <!-- Notes -->
                <div>
                  <label class="block text-amber-900 font-bold mb-2">Catatan Khusus (Opsional)</label>
                  <textarea
                    v-model="formData.notes"
                    placeholder="Contoh: Tanpa pedas, extra sayuran, dll."
                    rows="4"
                    class="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition resize-none"
                  ></textarea>
                </div>
              </div>
            </div>

            <!-- Payment Method -->
            <div class="bg-white rounded-2xl p-8 shadow-md">
              <h2 class="text-2xl font-bold text-amber-900 mb-6">💳 Metode Pembayaran</h2>

              <div class="space-y-3">
                <label class="flex items-center p-4 border-2 border-amber-200 rounded-lg cursor-pointer hover:bg-amber-50 transition" :class="{ 'border-orange-600 bg-orange-50': paymentMethod === 'cash' }">
                  <input v-model="paymentMethod" type="radio" value="cash" class="w-5 h-5" />
                  <span class="ml-4 font-bold text-amber-900">💵 Tunai (Cash)</span>
                </label>

                <label class="flex items-center p-4 border-2 border-amber-200 rounded-lg cursor-pointer hover:bg-amber-50 transition" :class="{ 'border-orange-600 bg-orange-50': paymentMethod === 'card' }">
                  <input v-model="paymentMethod" type="radio" value="card" class="w-5 h-5" />
                  <span class="ml-4 font-bold text-amber-900">🏧 Kartu Debit/Kredit</span>
                </label>

                <label class="flex items-center p-4 border-2 border-amber-200 rounded-lg cursor-pointer hover:bg-amber-50 transition" :class="{ 'border-orange-600 bg-orange-50': paymentMethod === 'ewallet' }">
                  <input v-model="paymentMethod" type="radio" value="ewallet" class="w-5 h-5" />
                  <span class="ml-4 font-bold text-amber-900">📱 E-Wallet (GoPay, OVO)</span>
                </label>
              </div>
            </div>

            <!-- Terms -->
            <div class="bg-amber-50 rounded-2xl p-6 border-2 border-amber-200">
              <label class="flex items-start gap-3 cursor-pointer">
                <input v-model="agreedToTerms" type="checkbox" class="w-5 h-5 mt-1" />
                <span class="text-sm text-amber-900">
                  Saya setuju dengan <a href="#" class="font-bold hover:underline">syarat dan ketentuan</a> serta <a href="#" class="font-bold hover:underline">kebijakan privasi</a> LocalBowls.
                </span>
              </label>
            </div>

            <!-- Submit Button -->
            <button
              type="submit"
              :disabled="!agreedToTerms || cartStore.items.length === 0"
              class="w-full py-4 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-xl font-bold text-lg hover:shadow-lg transition transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              ✓ Konfirmasi Pesanan
            </button>

            <!-- Back Button -->
            <router-link to="/keranjang" class="block w-full py-3 text-center border-2 border-amber-300 text-amber-900 rounded-lg font-bold hover:bg-amber-50 transition">
              ← Kembali ke Keranjang
            </router-link>
          </form>
        </div>

        <!-- Order Summary Sidebar -->
        <div class="sticky top-20 h-fit">
          <div class="bg-white rounded-2xl p-8 shadow-lg border-2 border-amber-200">
            <h2 class="text-2xl font-bold text-amber-900 mb-6">📝 Ringkasan Pesanan</h2>

            <!-- Items List -->
            <div class="space-y-3 mb-6 pb-6 border-b-2 border-amber-100 max-h-64 overflow-y-auto">
              <div v-for="item in cartStore.items" :key="item.cartItemId" class="flex justify-between text-sm">
                <span class="text-gray-600">{{ item.quantity }}x {{ item.name }}</span>
                <span class="font-bold text-amber-900">Rp {{ (item.price * item.quantity).toLocaleString('id-ID') }}</span>
              </div>
            </div>

            <!-- Cost Breakdown -->
            <div class="space-y-3 mb-6 pb-6 border-b-2 border-amber-100">
              <div class="flex justify-between text-gray-600">
                <span>Subtotal:</span>
                <span>Rp {{ cartStore.total.toLocaleString('id-ID') }}</span>
              </div>
              <div class="flex justify-between text-gray-600">
                <span>Biaya Layanan:</span>
                <span class="text-green-600">Gratis</span>
              </div>
              <div class="flex justify-between text-gray-600">
                <span>Ongkir:</span>
                <span>Rp 10.000</span>
              </div>
            </div>

            <!-- Total -->
            <div class="bg-gradient-to-r from-amber-100 to-orange-100 p-4 rounded-xl">
              <div class="flex justify-between items-center">
                <span class="font-bold text-amber-900">Total Bayar:</span>
                <span class="text-3xl font-bold text-orange-600">
                  Rp {{ (cartStore.total + 10000).toLocaleString('id-ID') }}
                </span>
              </div>
            </div>

            <!-- Info Box -->
            <div class="mt-6 p-4 bg-blue-50 border-l-4 border-blue-400 rounded">
              <p class="text-sm text-blue-900">
                <strong>ℹ️ Info:</strong> Pesanan Anda akan diproses setelah konfirmasi. Waktu tunggu ±15-20 menit.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '../store/cart.js'

const router = useRouter()
const cartStore = useCartStore()

const formData = ref({
  name: '',
  phone: '',
  table: '',
  notes: ''
})

const paymentMethod = ref('cash')
const agreedToTerms = ref(false)

const submitOrder = async () => {
  try {
    // Update customer info di store
    cartStore.setCustomerInfo({
      ...formData.value,
      paymentMethod: paymentMethod.value
    })

    // Simulate order submission
    const order = await cartStore.placeOrder()
    
    // Redirect to status page with order ID
    router.push(`/status?orderId=${order.orderId}`)
    
    // Clear form
    formData.value = { name: '', phone: '', table: '', notes: '' }
    agreedToTerms.value = false
  } catch (error) {
    alert('Gagal membuat pesanan: ' + error.message)
  }
}

onMounted(() => {
  document.title = 'Konfirmasi Pesanan - LocalBowls'
  
  if (cartStore.items.length === 0) {
    router.push('/menu')
  }
})
</script>