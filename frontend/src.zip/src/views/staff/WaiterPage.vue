<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white">
    <!-- Header Navigation -->
    <nav class="bg-gradient-to-r from-amber-900 to-orange-900 text-white p-4 sticky top-0 z-40">
      <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="text-2xl">👨‍🍳</div>
          <div>
            <h1 class="text-2xl font-bold">Waiter Dashboard</h1>
            <p class="text-amber-100 text-sm">{{ authStore.user?.name }}</p>
          </div>
        </div>
        <button
          @click="logout"
          class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg font-bold transition"
        >
          Logout
        </button>
      </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
      <!-- Stats Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-orange-500">
          <p class="text-gray-600 text-sm">Total Meja</p>
          <p class="text-4xl font-bold text-orange-600 mt-2">{{ tables.length }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-green-500">
          <p class="text-gray-600 text-sm">Meja Kosong</p>
          <p class="text-4xl font-bold text-green-600 mt-2">{{ emptyTables }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-blue-500">
          <p class="text-gray-600 text-sm">Meja Terpakai</p>
          <p class="text-4xl font-bold text-blue-600 mt-2">{{ occupiedTables }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-yellow-500">
          <p class="text-gray-600 text-sm">Pending Orders</p>
          <p class="text-4xl font-bold text-yellow-600 mt-2">{{ pendingOrders }}</p>
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex gap-4 mb-8 border-b-2 border-amber-200">
        <button
          @click="activeTab = 'tables'"
          :class="['px-6 py-3 font-bold transition border-b-4', activeTab === 'tables' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          🪑 Meja ({{ tables.length }})
        </button>
        <button
          @click="activeTab = 'orders'"
          :class="['px-6 py-3 font-bold transition border-b-4', activeTab === 'orders' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          📋 Pesanan ({{ pendingOrders }})
        </button>
      </div>

      <!-- Tables View -->
      <div v-if="activeTab === 'tables'" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            v-for="table in tables"
            :key="table.id"
            @click="selectTable(table)"
            :class="[
              'p-6 rounded-2xl cursor-pointer transition transform hover:scale-105 shadow-md',
              table.status === 'occupied' 
                ? 'bg-red-100 border-2 border-red-500' 
                : table.status === 'reserved'
                ? 'bg-yellow-100 border-2 border-yellow-500'
                : 'bg-green-100 border-2 border-green-500'
            ]"
          >
            <div class="text-center">
              <p class="text-4xl mb-2">🪑</p>
              <p class="text-2xl font-bold">{{ table.name }}</p>
              <p class="text-sm mt-2 font-bold">
                <span v-if="table.status === 'occupied'" class="text-red-700">Terpakai</span>
                <span v-else-if="table.status === 'reserved'" class="text-yellow-700">Dipesan</span>
                <span v-else class="text-green-700">Kosong</span>
              </p>
              <p v-if="table.capacity" class="text-xs text-gray-600 mt-1">{{ table.capacity }} orang</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Orders View -->
      <div v-if="activeTab === 'orders'" class="space-y-4">
        <div v-for="order in pendingOrdersList" :key="order.id" class="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
            <!-- Order Info -->
            <div>
              <p class="text-sm text-gray-600">No. Pesanan</p>
              <p class="text-2xl font-bold text-orange-600">#{{ order.id }}</p>
              <p class="text-sm text-gray-600 mt-2">Meja: <strong>{{ order.table }}</strong></p>
            </div>

            <!-- Items -->
            <div class="md:col-span-2">
              <p class="text-sm text-gray-600 mb-2">Items:</p>
              <ul class="space-y-1 text-sm">
                <li v-for="(item, idx) in order.items" :key="idx" class="text-amber-900">
                  {{ item.quantity }}x {{ item.name }}
                </li>
              </ul>
            </div>

            <!-- Actions -->
            <div class="space-y-2">
              <button
                @click="markOrderReady(order.id)"
                class="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition"
              >
                ✓ Siap Diantar
              </button>
              <button
                @click="markOrderIssue(order.id)"
                class="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold transition"
              >
                ⚠️ Ada Masalah
              </button>
            </div>
          </div>
        </div>

        <div v-if="pendingOrdersList.length === 0" class="text-center py-12">
          <p class="text-4xl mb-4">✓</p>
          <p class="text-gray-600 text-lg">Semua pesanan sudah siap diantar!</p>
        </div>
      </div>
    </div>

    <!-- Table Detail Modal -->
    <div v-if="selectedTable" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div class="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-bold text-amber-900">Meja {{ selectedTable.name }}</h2>
          <button @click="selectedTable = null" class="text-2xl hover:opacity-70">✕</button>
        </div>

        <div class="space-y-4 mb-6">
          <div>
            <p class="text-sm text-gray-600">Status</p>
            <p class="text-lg font-bold text-amber-900">
              <span v-if="selectedTable.status === 'occupied'" class="text-red-600">Terpakai</span>
              <span v-else-if="selectedTable.status === 'reserved'" class="text-yellow-600">Dipesan</span>
              <span v-else class="text-green-600">Kosong</span>
            </p>
          </div>
          <div>
            <p class="text-sm text-gray-600">Kapasitas</p>
            <p class="text-lg font-bold text-amber-900">{{ selectedTable.capacity }} orang</p>
          </div>
        </div>

        <div class="space-y-2">
          <button
            @click="setTableOccupied"
            class="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold transition"
          >
            Mark Terpakai
          </button>
          <button
            @click="setTableReserved"
            class="w-full px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg font-bold transition"
          >
            Mark Dipesan
          </button>
          <button
            @click="setTableEmpty"
            class="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition"
          >
            Mark Kosong
          </button>
          <button
            @click="selectedTable = null"
            class="w-full px-4 py-2 bg-gray-400 hover:bg-gray-500 text-white rounded-lg font-bold transition"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../store/auth.js'

const router = useRouter()
const authStore = useAuthStore()

const activeTab = ref('tables')
const selectedTable = ref(null)

const tables = ref([
  { id: 1, name: 'A-01', status: 'empty', capacity: 2 },
  { id: 2, name: 'A-02', status: 'occupied', capacity: 2 },
  { id: 3, name: 'A-03', status: 'empty', capacity: 4 },
  { id: 4, name: 'B-01', status: 'reserved', capacity: 4 },
  { id: 5, name: 'B-02', status: 'empty', capacity: 6 },
  { id: 6, name: 'B-03', status: 'occupied', capacity: 6 },
  { id: 7, name: 'C-01', status: 'empty', capacity: 8 },
  { id: 8, name: 'C-02', status: 'empty', capacity: 8 },
])

const pendingOrdersList = ref([
  { id: 1001, table: 'A-02', items: [{ name: 'Mie Kuah Spesial', quantity: 2 }, { name: 'Jeruk Segar', quantity: 1 }], status: 'preparing' },
  { id: 1002, table: 'B-01', items: [{ name: 'Nasi Kuning', quantity: 1 }, { name: 'Kopi Spesial', quantity: 2 }], status: 'preparing' },
])

const emptyTables = computed(() => tables.value.filter(t => t.status === 'empty').length)
const occupiedTables = computed(() => tables.value.filter(t => t.status === 'occupied').length)
const pendingOrders = computed(() => pendingOrdersList.value.filter(o => o.status === 'preparing').length)

const selectTable = (table) => {
  selectedTable.value = table
}

const setTableOccupied = () => {
  if (selectedTable.value) {
    const table = tables.value.find(t => t.id === selectedTable.value.id)
    if (table) {
      table.status = 'occupied'
      selectedTable.value = null
    }
  }
}

const setTableReserved = () => {
  if (selectedTable.value) {
    const table = tables.value.find(t => t.id === selectedTable.value.id)
    if (table) {
      table.status = 'reserved'
      selectedTable.value = null
    }
  }
}

const setTableEmpty = () => {
  if (selectedTable.value) {
    const table = tables.value.find(t => t.id === selectedTable.value.id)
    if (table) {
      table.status = 'empty'
      selectedTable.value = null
    }
  }
}

const markOrderReady = (orderId) => {
  const order = pendingOrdersList.value.find(o => o.id === orderId)
  if (order) {
    order.status = 'ready'
    alert(`Pesanan #${orderId} ditandai siap!`)
  }
}

const markOrderIssue = (orderId) => {
  alert(`Ada issue dengan pesanan #${orderId}. Hubungi chef!`)
}

const logout = () => {
  authStore.logout()
  router.push('/login')
}

onMounted(() => {
  if (!authStore.isAuthenticated || authStore.user?.role !== 'waiter') {
    router.push('/login')
  }
})
</script>