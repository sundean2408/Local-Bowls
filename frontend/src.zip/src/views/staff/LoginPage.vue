<template>
  <div class="min-h-screen bg-gradient-to-br from-amber-900 via-orange-900 to-amber-950 flex items-center justify-center py-8">
    <div class="w-full max-w-md">
      <!-- Card -->
      <div class="bg-white rounded-2xl shadow-2xl p-8">
        <!-- Logo & Title -->
        <div class="text-center mb-8">
          <div class="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-amber-600 to-orange-600 rounded-xl mb-4">
            <span class="text-3xl">🍜</span>
          </div>
          <h1 class="text-3xl font-bold text-amber-950">LocalBowls</h1>
          <p class="text-gray-600 text-sm mt-2">Staff Portal - Login</p>
        </div>

        <!-- Form -->
        <form @submit.prevent="handleLogin" class="space-y-4 mb-6">
          <!-- Email -->
          <div>
            <label class="block text-amber-900 font-bold mb-2">Email</label>
            <input
              v-model="email"
              type="email"
              placeholder="contoh: waiter@localbowls"
              required
              class="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition"
            />
          </div>

          <!-- Password -->
          <div>
            <label class="block text-amber-900 font-bold mb-2">Password</label>
            <input
              v-model="password"
              type="password"
              placeholder="Masukkan password"
              required
              class="w-full px-4 py-3 border-2 border-amber-200 rounded-lg focus:border-orange-600 focus:outline-none transition"
            />
          </div>

          <!-- Remember Me -->
          <label class="flex items-center gap-2 cursor-pointer">
            <input v-model="rememberMe" type="checkbox" class="w-4 h-4" />
            <span class="text-sm text-amber-900">Ingat saya</span>
          </label>

          <!-- Error Message -->
          <div v-if="errorMessage" class="p-3 bg-red-100 border-l-4 border-red-500 text-red-700 text-sm rounded">
            {{ errorMessage }}
          </div>

          <!-- Submit Button -->
          <button
            type="submit"
            :disabled="isLoading"
            class="w-full py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {{ isLoading ? 'Sedang Login...' : 'Login' }}
          </button>
        </form>

        <!-- Demo Credentials -->
        <div class="bg-amber-50 border-2 border-amber-200 rounded-lg p-4 mb-6">
          <p class="font-bold text-amber-900 text-sm mb-3">📝 Demo Credentials:</p>
          <div class="space-y-2 text-xs">
            <div class="flex justify-between text-amber-800">
              <span><strong>Waiter:</strong></span>
              <span>waiter@localbowls / pass123</span>
            </div>
            <div class="flex justify-between text-amber-800">
              <span><strong>Kitchen:</strong></span>
              <span>kitchen@localbowls / pass123</span>
            </div>
            <div class="flex justify-between text-amber-800">
              <span><strong>Cashier:</strong></span>
              <span>cashier@localbowls / pass123</span>
            </div>
            <div class="flex justify-between text-amber-800">
              <span><strong>Admin:</strong></span>
              <span>admin@localbowls / pass123</span>
            </div>
          </div>
        </div>

        <!-- Back to Home -->
        <router-link to="/" class="block text-center text-amber-600 hover:text-orange-600 font-bold transition">
          ← Kembali ke Beranda
        </router-link>
      </div>

      <!-- Footer -->
      <div class="text-center mt-8 text-amber-100 text-sm">
        <p>© 2024 LocalBowls Management System</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../store/auth.js'

const router = useRouter()
const authStore = useAuthStore()

const email = ref('')
const password = ref('')
const rememberMe = ref(false)
const errorMessage = ref('')
const isLoading = ref(false)

const handleLogin = async () => {
  errorMessage.value = ''
  isLoading.value = true

  try {
    await authStore.login(email.value, password.value, rememberMe.value)
    
    // Redirect based on role
    const roleRoutes = {
      waiter: '/waiter',
      kitchen: '/dapur',
      cashier: '/kasir',
      admin: '/admin'
    }
    
    const redirectPath = roleRoutes[authStore.user.role] || '/waiter'
    router.push(redirectPath)
  } catch (error) {
    errorMessage.value = error.message || 'Login gagal. Coba lagi!'
  } finally {
    isLoading.value = false
  }
}
</script>