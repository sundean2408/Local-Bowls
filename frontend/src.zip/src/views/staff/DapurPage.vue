<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white">
    <!-- Header Navigation -->
    <nav class="bg-gradient-to-r from-amber-900 to-orange-900 text-white p-4 sticky top-0 z-40">
      <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="text-2xl">👨‍🍳</div>
          <div>
            <h1 class="text-2xl font-bold">Kitchen Dashboard</h1>
            <p class="text-amber-100 text-sm">{{ authStore.user?.name }}</p>
          </div>
        </div>
        <button
          @click="logout"
          class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg font-bold transition"
        >
          Logout
        </button>
      </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
      <!-- Stats Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-red-500">
          <p class="text-gray-600 text-sm">Pesanan Baru</p>
          <p class="text-4xl font-bold text-red-600 mt-2">{{ newOrders.length }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-orange-500">
          <p class="text-gray-600 text-sm">Sedang Dimasak</p>
          <p class="text-4xl font-bold text-orange-600 mt-2">{{ cookingOrders.length }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-green-500">
          <p class="text-gray-600 text-sm">Siap Diantar</p>
          <p class="text-4xl font-bold text-green-600 mt-2">{{ readyOrders.length }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-purple-500">
          <p class="text-gray-600 text-sm">Total Pesanan</p>
          <p class="text-4xl font-bold text-purple-600 mt-2">{{ orders.length }}</p>
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex gap-4 mb-8 border-b-2 border-amber-200 overflow-x-auto">
        <button
          @click="activeTab = 'new'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'new' ? 'border-red-600 text-red-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          🆕 Baru ({{ newOrders.length }})
        </button>
        <button
          @click="activeTab = 'cooking'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'cooking' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          🍳 Dimasak ({{ cookingOrders.length }})
        </button>
        <button
          @click="activeTab = 'ready'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'ready' ? 'border-green-600 text-green-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          ✓ Siap ({{ readyOrders.length }})
        </button>
      </div>

      <!-- Orders Display -->
      <div class="space-y-4">
        <!-- New Orders -->
        <template v-if="activeTab === 'new'">
          <div v-for="order in newOrders" :key="order.id" class="bg-red-50 border-4 border-red-500 rounded-2xl p-6 shadow-md hover:shadow-lg transition">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
              <!-- Order Info -->
              <div>
                <p class="text-sm text-gray-600">No. Pesanan</p>
                <p class="text-3xl font-bold text-red-600">#{{ order.id }}</p>
                <p class="text-sm text-gray-600 mt-2">Meja: <strong>{{ order.table }}</strong></p>
                <p class="text-xs text-gray-500 mt-1">Waktu: {{ formatTime(order.time) }}</p>
              </div>

              <!-- Items -->
              <div class="md:col-span-2">
                <p class="text-sm text-gray-600 font-bold mb-3">Items untuk dimasak:</p>
                <div class="space-y-2">
                  <div v-for="(item, idx) in order.items" :key="idx" class="bg-white p-3 rounded-lg border-l-4 border-red-500">
                    <p class="font-bold text-amber-900">{{ item.quantity }}x {{ item.name }}</p>
                    <p v-if="item.notes" class="text-xs text-gray-600 mt-1">📝 {{ item.notes }}</p>
                  </div>
                </div>
              </div>

              <!-- Actions -->
              <div class="space-y-2">
                <button
                  @click="startCooking(order.id)"
                  class="w-full px-4 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-bold transition text-sm"
                >
                  🍳 Mulai Masak
                </button>
              </div>
            </div>
          </div>

          <div v-if="newOrders.length === 0" class="text-center py-12 bg-white rounded-2xl">
            <p class="text-gray-600 text-lg">Tidak ada pesanan baru</p>
          </div>
        </template>

        <!-- Cooking Orders -->
        <template v-if="activeTab === 'cooking'">
          <div v-for="order in cookingOrders" :key="order.id" class="bg-orange-50 border-4 border-orange-500 rounded-2xl p-6 shadow-md hover:shadow-lg transition">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
              <!-- Order Info -->
              <div>
                <p class="text-sm text-gray-600">No. Pesanan</p>
                <p class="text-3xl font-bold text-orange-600">#{{ order.id }}</p>
                <p class="text-sm text-gray-600 mt-2">Meja: <strong>{{ order.table }}</strong></p>
                <p class="text-xs text-gray-500 mt-1">Waktu: {{ formatTime(order.time) }}</p>
              </div>

              <!-- Items with Progress -->
              <div class="md:col-span-2">
                <p class="text-sm text-gray-600 font-bold mb-3">Sedang dimasak:</p>
                <div class="space-y-2">
                  <div v-for="(item, idx) in order.items" :key="idx" class="bg-white p-3 rounded-lg border-l-4 border-orange-500">
                    <p class="font-bold text-amber-900">{{ item.quantity }}x {{ item.name }}</p>
                    <div class="mt-2 flex items-center gap-2">
                      <div class="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div class="h-full bg-orange-500" :style="{ width: item.progress + '%' }"></div>
                      </div>
                      <span class="text-xs text-gray-600">{{ item.progress }}%</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Actions -->
              <div class="space-y-2">
                <button
                  @click="completeOrder(order.id)"
                  class="w-full px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition text-sm"
                >
                  ✓ Selesai Masak
                </button>
                <button
                  @click="reportIssue(order.id)"
                  class="w-full px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold transition text-sm"
                >
                  ⚠️ Ada Masalah
                </button>
              </div>
            </div>
          </div>

          <div v-if="cookingOrders.length === 0" class="text-center py-12 bg-white rounded-2xl">
            <p class="text-gray-600 text-lg">Tidak ada pesanan yang sedang dimasak</p>
          </div>
        </template>

        <!-- Ready Orders -->
        <template v-if="activeTab === 'ready'">
          <div v-for="order in readyOrders" :key="order.id" class="bg-green-50 border-4 border-green-500 rounded-2xl p-6 shadow-md hover:shadow-lg transition">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
              <!-- Order Info -->
              <div>
                <p class="text-sm text-gray-600">No. Pesanan</p>
                <p class="text-3xl font-bold text-green-600">#{{ order.id }}</p>
                <p class="text-sm text-gray-600 mt-2">Meja: <strong>{{ order.table }}</strong></p>
                <p class="text-xs text-gray-500 mt-1">Waktu: {{ formatTime(order.time) }}</p>
              </div>

              <!-- Items -->
              <div class="md:col-span-2">
                <p class="text-sm text-gray-600 font-bold mb-3">Siap untuk diantar:</p>
                <ul class="space-y-1">
                  <li v-for="(item, idx) in order.items" :key="idx" class="text-amber-900 font-semibold">
                    ✓ {{ item.quantity }}x {{ item.name }}
                  </li>
                </ul>
              </div>

              <!-- Actions -->
              <div>
                <p class="text-xs text-gray-500 text-center py-2 bg-green-100 rounded-lg">
                  ✓ Menunggu waiter untuk diantar
                </p>
              </div>
            </div>
          </div>

          <div v-if="readyOrders.length === 0" class="text-center py-12 bg-white rounded-2xl">
            <p class="text-gray-600 text-lg">Tidak ada pesanan yang siap</p>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../store/auth.js'

const router = useRouter()
const authStore = useAuthStore()

const activeTab = ref('new')

const orders = ref([
  {
    id: 1001,
    table: 'A-02',
    status: 'new',
    time: new Date(Date.now() - 2 * 60000),
    items: [
      { name: 'Mie Kuah Spesial', quantity: 2, notes: 'Tanpa pedas', progress: 0 },
      { name: 'Jeruk Segar', quantity: 1, notes: '', progress: 0 }
    ]
  },
  {
    id: 1002,
    table: 'B-01',
    status: 'new',
    time: new Date(Date.now() - 1 * 60000),
    items: [
      { name: 'Nasi Kuning', quantity: 1, notes: '', progress: 0 },
      { name: 'Kopi Spesial', quantity: 2, notes: 'Extra panas', progress: 0 }
    ]
  },
  {
    id: 1003,
    table: 'A-01',
    status: 'cooking',
    time: new Date(Date.now() - 8 * 60000),
    items: [
      { name: 'Spaghetti Carbonara', quantity: 1, notes: '', progress: 65 },
      { name: 'Teh Herbal', quantity: 1, notes: '', progress: 90 }
    ]
  },
  {
    id: 1004,
    table: 'C-01',
    status: 'ready',
    time: new Date(Date.now() - 12 * 60000),
    items: [
      { name: 'Sup Ayam', quantity: 2, notes: '', progress: 100 }
    ]
  }
])

const newOrders = computed(() => orders.value.filter(o => o.status === 'new'))
const cookingOrders = computed(() => orders.value.filter(o => o.status === 'cooking'))
const readyOrders = computed(() => orders.value.filter(o => o.status === 'ready'))

const startCooking = (orderId) => {
  const order = orders.value.find(o => o.id === orderId)
  if (order) {
    order.status = 'cooking'
    // Initialize progress
    order.items.forEach(item => {
      item.progress = 0
      // Simulate cooking progress
      const interval = setInterval(() => {
        if (item.progress < 100) {
          item.progress += Math.random() * 20
          if (item.progress > 100) item.progress = 100
        } else {
          clearInterval(interval)
        }
      }, 2000)
    })
  }
}

const completeOrder = (orderId) => {
  const order = orders.value.find(o => o.id === orderId)
  if (order) {
    order.status = 'ready'
    alert(`Pesanan #${orderId} selesai dimasak!`)
  }
}

const reportIssue = (orderId) => {
  alert(`Ada issue dengan pesanan #${orderId}. Segera hubungi manager!`)
}

const formatTime = (date) => {
  return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
}

const logout = () => {
  authStore.logout()
  router.push('/login')
}

onMounted(() => {
  if (!authStore.isAuthenticated || authStore.user?.role !== 'kitchen') {
    router.push('/login')
  }
})
</script>