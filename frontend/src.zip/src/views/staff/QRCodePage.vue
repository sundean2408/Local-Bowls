<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import QRCode from 'qrcode'
import api from '../../services/api'

const router = useRouter()

const daftarMeja = ref([])
const qrDataUrls = ref({}) // { [idMeja]: 'data:image/png;base64,...' }
const loading = ref(true)
const error = ref(null)

function urlUntukMeja(idMeja) {
  // Format URL sesuai yang beneran dibaca aplikasi (query param ?meja=<id>),
  // BUKAN format kolom `qr_code` di database (yang isinya "table=1" dkk —
  // itu tidak dipakai oleh routing/logic aplikasi manapun).
  return `${window.location.origin}/?meja=${idMeja}`
}

async function generateSemuaQR() {
  for (const meja of daftarMeja.value) {
    try {
      const dataUrl = await QRCode.toDataURL(urlUntukMeja(meja.id), {
        width: 300,
        margin: 1,
        color: { dark: '#243127', light: '#FFFFFF' },
      })
      qrDataUrls.value[meja.id] = dataUrl
    } catch (e) {
      console.error('Gagal generate QR untuk meja', meja.id, e)
    }
  }
}

async function fetchMeja() {
  loading.value = true
  error.value = null
  try {
    const res = await api.get('/meja')
    daftarMeja.value = res.data.data ?? res.data
    await generateSemuaQR()
  } catch (e) {
    error.value = 'Gagal memuat data meja. Pastikan backend berjalan & kamu masih login.'
    console.error(e)
  } finally {
    loading.value = false
  }
}

function cetakSemua() {
  window.print()
}

async function logout() {
  try {
    await api.post('/logout')
  } catch (e) {
    console.error(e)
  } finally {
    localStorage.removeItem('token')
    router.push('/login')
  }
}

onMounted(fetchMeja)
</script>

<template>
  <div class="min-h-screen bg-white [font-family:'Plus_Jakarta_Sans',_system-ui,_sans-serif]">
    <!-- Navbar kop nota -->
    <nav class="bg-[#3F6048] px-8 py-5 no-print">
      <div class="flex items-center justify-between max-w-5xl mx-auto">
        <div class="flex items-center gap-3">
          <img src="/logo.png" alt="Local Bowls" class="h-8 w-auto object-contain flex-shrink-0" />
          <div>
            <h1 class="[font-family:'Fraunces',_serif] text-lg tracking-wide text-white">Local Bowls</h1>
            <p class="text-[10px] tracking-[3px] text-[#D9A441] [font-family:'Space_Mono',_monospace]">QR CODE MEJA</p>
          </div>
        </div>
        <button @click="logout" class="text-xs tracking-wide text-white/70 hover:text-[#D9A441] transition">
          KELUAR →
        </button>
      </div>
    </nav>

    <!-- pita batik -->
    <div
      class="h-[6px] w-full no-print"
      style="background: repeating-linear-gradient(135deg, #3F6048 0 10px, #D9A441 10px 20px);"
    ></div>

    <div class="max-w-5xl mx-auto px-6 py-10">
      <div class="mb-8 border-b-2 border-dashed border-[#243127]/20 pb-4 flex items-center justify-between no-print">
        <div>
          <p class="text-xs tracking-[3px] text-[#D9A441] [font-family:'Space_Mono',_monospace] mb-1">CETAK QR</p>
          <h2 class="[font-family:'Fraunces',_serif] text-3xl text-[#243127]">QR Code Tiap Meja</h2>
          <p class="text-sm text-[#6B756D] mt-1">Scan kode ini akan membuka halaman menu langsung untuk meja tersebut.</p>
        </div>
        <button
          @click="cetakSemua"
          class="bg-[#D9A441] text-[#243127] text-sm font-semibold px-5 py-2.5 rounded-full hover:bg-[#c6923a] transition flex-shrink-0"
        >
          🖨 Cetak Semua
        </button>
      </div>

      <div v-if="loading" class="text-center text-[#6B756D] py-16 [font-family:'Space_Mono',_monospace] text-sm no-print">MEMBUAT QR CODE...</div>
      <div v-else-if="error" class="text-center text-[#B94A48] py-16 no-print">{{ error }}</div>

      <div v-else class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6 qr-grid">
        <div
          v-for="meja in daftarMeja"
          :key="meja.id"
          class="qr-card border-2 border-dashed border-[#243127]/25 rounded-lg p-5 text-center"
        >
          <p class="text-[10px] tracking-[3px] text-[#6B756D] [font-family:'Space_Mono',_monospace] mb-1">LOCAL BOWLS</p>
          <p class="text-2xl font-bold text-[#243127] [font-family:'Fraunces',_serif] mb-3">MEJA {{ meja.nomor_meja }}</p>

          <img
            v-if="qrDataUrls[meja.id]"
            :src="qrDataUrls[meja.id]"
            :alt="`QR Meja ${meja.nomor_meja}`"
            class="w-full max-w-[180px] mx-auto mb-3"
          />
          <div v-else class="w-full max-w-[180px] aspect-square mx-auto mb-3 bg-[#F7F9F5] flex items-center justify-center text-xs text-[#6B756D]">
            Memuat...
          </div>

          <p class="text-[10px] text-[#6B756D] tracking-wide">SCAN UNTUK PESAN</p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap');

/* Saat print: sembunyikan navbar/tombol, rapikan grid QR jadi kartu-kartu siap gunting */
@media print {
  .no-print {
    display: none !important;
  }
  .qr-grid {
    grid-template-columns: repeat(3, 1fr) !important;
    gap: 12px !important;
  }
  .qr-card {
    break-inside: avoid;
    page-break-inside: avoid;
  }
}
</style>