<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white">
    <!-- Header Navigation -->
    <nav class="bg-gradient-to-r from-amber-900 to-orange-900 text-white p-4 sticky top-0 z-40">
      <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="text-2xl">💳</div>
          <div>
            <h1 class="text-2xl font-bold">Cashier Dashboard</h1>
            <p class="text-amber-100 text-sm">{{ authStore.user?.name }}</p>
          </div>
        </div>
        <button
          @click="logout"
          class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg font-bold transition"
        >
          Logout
        </button>
      </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
      <!-- Stats Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-green-500">
          <p class="text-gray-600 text-sm">Total Revenue</p>
          <p class="text-3xl font-bold text-green-600 mt-2">Rp {{ totalRevenue.toLocaleString('id-ID') }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-blue-500">
          <p class="text-gray-600 text-sm">Transaksi Hari Ini</p>
          <p class="text-4xl font-bold text-blue-600 mt-2">{{ todayTransactions }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-orange-500">
          <p class="text-gray-600 text-sm">Pesanan Menunggu</p>
          <p class="text-4xl font-bold text-orange-600 mt-2">{{ pendingPayments.length }}</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-purple-500">
          <p class="text-gray-600 text-sm">Avg Transaction</p>
          <p class="text-3xl font-bold text-purple-600 mt-2">Rp {{ avgTransaction.toLocaleString('id-ID') }}</p>
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex gap-4 mb-8 border-b-2 border-amber-200 overflow-x-auto">
        <button
          @click="activeTab = 'pending'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'pending' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          ⏳ Menunggu Pembayaran ({{ pendingPayments.length }})
        </button>
        <button
          @click="activeTab = 'completed'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'completed' ? 'border-green-600 text-green-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          ✓ Sudah Dibayar ({{ completedPayments.length }})
        </button>
        <button
          @click="activeTab = 'report'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'report' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          📊 Laporan Harian
        </button>
      </div>

      <!-- Pending Payments -->
      <template v-if="activeTab === 'pending'">
        <div class="space-y-4">
          <div v-for="payment in pendingPayments" :key="payment.id" class="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition border-l-4 border-orange-500">
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
              <!-- Order Info -->
              <div>
                <p class="text-sm text-gray-600">No. Pesanan</p>
                <p class="text-2xl font-bold text-orange-600">#{{ payment.orderId }}</p>
                <p class="text-xs text-gray-500 mt-1">Meja: {{ payment.table }}</p>
              </div>

              <!-- Items Summary -->
              <div>
                <p class="text-sm text-gray-600">Items</p>
                <p class="font-bold text-amber-900">{{ payment.itemCount }} item</p>
                <p class="text-xs text-gray-600 mt-1">{{ formatTime(payment.orderTime) }}</p>
              </div>

              <!-- Amount -->
              <div>
                <p class="text-sm text-gray-600">Total</p>
                <p class="text-2xl font-bold text-green-600">Rp {{ payment.amount.toLocaleString('id-ID') }}</p>
              </div>

              <!-- Payment Method Selection -->
              <div>
                <p class="text-sm text-gray-600 mb-2">Metode</p>
                <select class="px-3 py-2 border-2 border-amber-200 rounded-lg text-sm focus:border-orange-600 focus:outline-none w-full">
                  <option value="cash">💵 Tunai</option>
                  <option value="card">🏧 Kartu</option>
                  <option value="ewallet">📱 E-Wallet</option>
                </select>
              </div>

              <!-- Actions -->
              <div class="space-y-2">
                <button
                  @click="processPayment(payment.id)"
                  class="w-full px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition text-sm"
                >
                  ✓ Konfirmasi
                </button>
                <button
                  @click="cancelPayment(payment.id)"
                  class="w-full px-4 py-2 bg-gray-400 hover:bg-gray-500 text-white rounded-lg font-bold transition text-sm"
                >
                  ✕ Batal
                </button>
              </div>
            </div>
          </div>

          <div v-if="pendingPayments.length === 0" class="text-center py-12 bg-white rounded-2xl">
            <p class="text-gray-600 text-lg">✓ Semua pembayaran sudah diproses!</p>
          </div>
        </div>
      </template>

      <!-- Completed Payments -->
      <template v-if="activeTab === 'completed'">
        <div class="space-y-4">
          <div v-for="payment in completedPayments" :key="payment.id" class="bg-green-50 rounded-2xl p-6 shadow-md border-l-4 border-green-500">
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
              <!-- Order Info -->
              <div>
                <p class="text-sm text-gray-600">No. Pesanan</p>
                <p class="text-2xl font-bold text-green-600">#{{ payment.orderId }}</p>
                <p class="text-xs text-gray-500 mt-1">Meja: {{ payment.table }}</p>
              </div>

              <!-- Items Summary -->
              <div>
                <p class="text-sm text-gray-600">Items</p>
                <p class="font-bold text-amber-900">{{ payment.itemCount }} item</p>
                <p class="text-xs text-gray-600 mt-1">{{ formatTime(payment.orderTime) }}</p>
              </div>

              <!-- Amount -->
              <div>
                <p class="text-sm text-gray-600">Total</p>
                <p class="text-2xl font-bold text-green-600">Rp {{ payment.amount.toLocaleString('id-ID') }}</p>
              </div>

              <!-- Payment Method -->
              <div>
                <p class="text-sm text-gray-600">Metode</p>
                <p class="font-bold text-amber-900">{{ payment.method }}</p>
              </div>

              <!-- Time -->
              <div class="text-center">
                <p class="text-sm text-gray-600">Waktu Bayar</p>
                <p class="font-bold text-green-600">{{ formatTime(payment.paymentTime) }}</p>
              </div>
            </div>
          </div>

          <div v-if="completedPayments.length === 0" class="text-center py-12 bg-white rounded-2xl">
            <p class="text-gray-600 text-lg">Belum ada pembayaran yang selesai</p>
          </div>
        </div>
      </template>

      <!-- Daily Report -->
      <template v-if="activeTab === 'report'">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <!-- Summary Card -->
          <div class="lg:col-span-1">
            <div class="bg-white rounded-2xl p-8 shadow-md">
              <h2 class="text-2xl font-bold text-amber-900 mb-6">📊 Ringkasan Hari Ini</h2>

              <div class="space-y-4">
                <!-- Total Sales -->
                <div class="p-4 bg-green-50 border-l-4 border-green-500 rounded-lg">
                  <p class="text-sm text-gray-600">Total Penjualan</p>
                  <p class="text-3xl font-bold text-green-600 mt-2">Rp {{ totalRevenue.toLocaleString('id-ID') }}</p>
                </div>

                <!-- Transaction Count -->
                <div class="p-4 bg-blue-50 border-l-4 border-blue-500 rounded-lg">
                  <p class="text-sm text-gray-600">Jumlah Transaksi</p>
                  <p class="text-3xl font-bold text-blue-600 mt-2">{{ todayTransactions }}</p>
                </div>

                <!-- Average -->
                <div class="p-4 bg-purple-50 border-l-4 border-purple-500 rounded-lg">
                  <p class="text-sm text-gray-600">Rata-rata Transaksi</p>
                  <p class="text-3xl font-bold text-purple-600 mt-2">Rp {{ avgTransaction.toLocaleString('id-ID') }}</p>
                </div>

                <!-- Payment Methods -->
                <div class="p-4 bg-amber-50 border-l-4 border-amber-500 rounded-lg">
                  <p class="text-sm font-bold text-amber-900 mb-3">Metode Pembayaran</p>
                  <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                      <span>💵 Tunai:</span>
                      <span class="font-bold">Rp {{ paymentMethods.cash.toLocaleString('id-ID') }}</span>
                    </div>
                    <div class="flex justify-between">
                      <span>🏧 Kartu:</span>
                      <span class="font-bold">Rp {{ paymentMethods.card.toLocaleString('id-ID') }}</span>
                    </div>
                    <div class="flex justify-between">
                      <span>📱 E-Wallet:</span>
                      <span class="font-bold">Rp {{ paymentMethods.ewallet.toLocaleString('id-ID') }}</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Export Button -->
              <button class="w-full mt-6 px-4 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition">
                📥 Export Laporan
              </button>
            </div>
          </div>

          <!-- Chart Area -->
          <div class="lg:col-span-2">
            <div class="bg-white rounded-2xl p-8 shadow-md">
              <h2 class="text-2xl font-bold text-amber-900 mb-6">📈 Grafik Penjualan</h2>

              <!-- Simple Bar Chart -->
              <div class="space-y-4">
                <div v-for="hour in hourlyData" :key="hour.hour" class="flex items-center gap-4">
                  <span class="w-12 text-sm font-bold text-gray-600">{{ hour.hour }}:00</span>
                  <div class="flex-1 h-8 bg-gray-200 rounded-lg overflow-hidden">
                    <div
                      class="h-full bg-gradient-to-r from-amber-600 to-orange-600 rounded-lg transition-all"
                      :style="{ width: (hour.sales / 2000000) * 100 + '%' }"
                    ></div>
                  </div>
                  <span class="text-sm font-bold text-orange-600 min-w-24 text-right">
                    Rp {{ hour.sales.toLocaleString('id-ID') }}
                  </span>
                </div>
              </div>

              <!-- Info Box -->
              <div class="mt-6 p-4 bg-blue-50 border-l-4 border-blue-400 rounded">
                <p class="text-sm text-blue-900">
                  <strong>📊 Info:</strong> Grafik menunjukkan penjualan per jam selama hari ini. Peak hours ada di siang hari (11:00 - 14:00).
                </p>
              </div>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../store/auth.js'

const router = useRouter()
const authStore = useAuthStore()

const activeTab = ref('pending')

const payments = ref([
  { id: 1, orderId: 1001, table: 'A-02', itemCount: 3, amount: 80000, method: 'cash', orderTime: new Date(Date.now() - 25 * 60000), paymentTime: null, status: 'pending' },
  { id: 2, orderId: 1002, table: 'B-01', itemCount: 3, amount: 65000, method: 'ewallet', orderTime: new Date(Date.now() - 22 * 60000), paymentTime: null, status: 'pending' },
  { id: 3, orderId: 1003, table: 'A-01', itemCount: 2, amount: 45000, method: 'card', orderTime: new Date(Date.now() - 18 * 60000), paymentTime: new Date(Date.now() - 2 * 60000), status: 'completed' },
  { id: 4, orderId: 1004, table: 'C-01', itemCount: 2, amount: 55000, method: 'cash', orderTime: new Date(Date.now() - 15 * 60000), paymentTime: new Date(Date.now() - 5 * 60000), status: 'completed' },
])

const pendingPayments = computed(() => payments.value.filter(p => p.status === 'pending'))
const completedPayments = computed(() => payments.value.filter(p => p.status === 'completed'))

const todayTransactions = computed(() => completedPayments.value.length)
const totalRevenue = computed(() => completedPayments.value.reduce((sum, p) => sum + p.amount, 0))
const avgTransaction = computed(() => todayTransactions.value > 0 ? Math.floor(totalRevenue.value / todayTransactions.value) : 0)

const paymentMethods = computed(() => ({
  cash: completedPayments.value.filter(p => p.method === 'cash').reduce((sum, p) => sum + p.amount, 0),
  card: completedPayments.value.filter(p => p.method === 'card').reduce((sum, p) => sum + p.amount, 0),
  ewallet: completedPayments.value.filter(p => p.method === 'ewallet').reduce((sum, p) => sum + p.amount, 0),
}))

const hourlyData = ref([
  { hour: 10, sales: 250000 },
  { hour: 11, sales: 650000 },
  { hour: 12, sales: 1200000 },
  { hour: 13, sales: 950000 },
  { hour: 14, sales: 800000 },
  { hour: 15, sales: 400000 },
  { hour: 16, sales: 350000 },
  { hour: 17, sales: 480000 },
])

const processPayment = (paymentId) => {
  const payment = payments.value.find(p => p.id === paymentId)
  if (payment) {
    payment.status = 'completed'
    payment.paymentTime = new Date()
    alert(`Pembayaran pesanan #${payment.orderId} berhasil diproses!`)
  }
}

const cancelPayment = (paymentId) => {
  const payment = payments.value.find(p => p.id === paymentId)
  if (payment) {
    if (confirm('Yakin ingin membatalkan pembayaran ini?')) {
      payments.value = payments.value.filter(p => p.id !== paymentId)
    }
  }
}

const formatTime = (date) => {
  return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
}

const logout = () => {
  authStore.logout()
  router.push('/login')
}

onMounted(() => {
  if (!authStore.isAuthenticated || authStore.user?.role !== 'cashier') {
    router.push('/login')
  }
})
</script>