<template>
  <div class="min-h-screen bg-gradient-to-b from-amber-50 to-white">
    <!-- Header Navigation -->
    <nav class="bg-gradient-to-r from-amber-900 to-orange-900 text-white p-4 sticky top-0 z-40">
      <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="text-2xl">👨‍💼</div>
          <div>
            <h1 class="text-2xl font-bold">Admin Dashboard</h1>
            <p class="text-amber-100 text-sm">{{ authStore.user?.name }}</p>
          </div>
        </div>
        <button
          @click="logout"
          class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg font-bold transition"
        >
          Logout
        </button>
      </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
      <!-- KPI Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-green-500">
          <p class="text-gray-600 text-sm">Profit Hari Ini</p>
          <p class="text-3xl font-bold text-green-600 mt-2">Rp {{ todayProfit.toLocaleString('id-ID') }}</p>
          <p class="text-xs text-green-600 mt-2">↑ +12.5% dari kemarin</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-blue-500">
          <p class="text-gray-600 text-sm">Total Pesanan</p>
          <p class="text-4xl font-bold text-blue-600 mt-2">{{ totalOrders }}</p>
          <p class="text-xs text-blue-600 mt-2">Hari ini</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-purple-500">
          <p class="text-gray-600 text-sm">Avg Order Value</p>
          <p class="text-3xl font-bold text-purple-600 mt-2">Rp {{ avgOrderValue.toLocaleString('id-ID') }}</p>
          <p class="text-xs text-purple-600 mt-2">↑ +5.2% dari kemarin</p>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-md border-t-4 border-orange-500">
          <p class="text-gray-600 text-sm">Customer Satisfaction</p>
          <p class="text-4xl font-bold text-orange-600 mt-2">4.8/5 ⭐</p>
          <p class="text-xs text-orange-600 mt-2">Berdasarkan 128 review</p>
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex gap-4 mb-8 border-b-2 border-amber-200 overflow-x-auto">
        <button
          @click="activeTab = 'overview'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'overview' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          📊 Overview
        </button>
        <button
          @click="activeTab = 'menu'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'menu' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          🍜 Menu Management
        </button>
        <button
          @click="activeTab = 'staff'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'staff' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          👥 Staff Management
        </button>
        <button
          @click="activeTab = 'analytics'"
          :class="['px-6 py-3 font-bold transition border-b-4 whitespace-nowrap', activeTab === 'analytics' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-600 hover:text-amber-900']"
        >
          📈 Analytics
        </button>
      </div>

      <!-- Overview Tab -->
      <template v-if="activeTab === 'overview'">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <!-- Orders Timeline -->
          <div class="bg-white rounded-2xl p-8 shadow-md">
            <h2 class="text-2xl font-bold text-amber-900 mb-6">📋 Recent Orders</h2>
            <div class="space-y-4">
              <div v-for="order in recentOrders" :key="order.id" class="flex justify-between items-center p-4 bg-amber-50 rounded-lg hover:bg-amber-100 transition">
                <div>
                  <p class="font-bold text-amber-900">#{{ order.id }} - {{ order.table }}</p>
                  <p class="text-sm text-gray-600">{{ order.items }} items</p>
                </div>
                <div class="text-right">
                  <p class="font-bold text-green-600">Rp {{ order.amount.toLocaleString('id-ID') }}</p>
                  <p class="text-xs text-gray-500">{{ formatTime(order.time) }}</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Top Menu Items -->
          <div class="bg-white rounded-2xl p-8 shadow-md">
            <h2 class="text-2xl font-bold text-amber-900 mb-6">🏆 Top Selling Items</h2>
            <div class="space-y-4">
              <div v-for="(item, idx) in topItems" :key="idx" class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <span class="text-3xl">{{ idx + 1 }}</span>
                  <div>
                    <p class="font-bold text-amber-900">{{ item.name }}</p>
                    <p class="text-xs text-gray-600">{{ item.sold }} terjual</p>
                  </div>
                </div>
                <div class="w-32 h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div class="h-full bg-gradient-to-r from-amber-600 to-orange-600" :style="{ width: (item.sold / 156) * 100 + '%' }"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>

      <!-- Menu Management Tab -->
      <template v-if="activeTab === 'menu'">
        <div class="space-y-6">
          <!-- Add Menu Button -->
          <button class="px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition">
            ➕ Tambah Menu Item Baru
          </button>

          <!-- Menu Items Table -->
          <div class="bg-white rounded-2xl overflow-hidden shadow-md">
            <div class="overflow-x-auto">
              <table class="w-full">
                <thead class="bg-amber-100">
                  <tr>
                    <th class="px-6 py-4 text-left font-bold text-amber-900">Item</th>
                    <th class="px-6 py-4 text-left font-bold text-amber-900">Harga</th>
                    <th class="px-6 py-4 text-left font-bold text-amber-900">Kategori</th>
                    <th class="px-6 py-4 text-left font-bold text-amber-900">Stock</th>
                    <th class="px-6 py-4 text-left font-bold text-amber-900">Status</th>
                    <th class="px-6 py-4 text-left font-bold text-amber-900">Aksi</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-amber-100">
                  <tr v-for="item in menuItems" :key="item.id" class="hover:bg-amber-50 transition">
                    <td class="px-6 py-4 font-bold text-amber-900">{{ item.name }}</td>
                    <td class="px-6 py-4">Rp {{ item.price.toLocaleString('id-ID') }}</td>
                    <td class="px-6 py-4">{{ item.category }}</td>
                    <td class="px-6 py-4">
                      <span :class="['px-3 py-1 rounded-full text-sm font-bold', item.stock > 10 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700']">
                        {{ item.stock }}
                      </span>
                    </td>
                    <td class="px-6 py-4">
                      <span :class="['px-3 py-1 rounded-full text-sm font-bold', item.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700']">
                        {{ item.active ? 'Aktif' : 'Nonaktif' }}
                      </span>
                    </td>
                    <td class="px-6 py-4 space-x-2">
                      <button class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 transition text-sm">Edit</button>
                      <button class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 transition text-sm">Delete</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </template>

      <!-- Staff Management Tab -->
      <template v-if="activeTab === 'staff'">
        <div class="space-y-6">
          <!-- Add Staff Button -->
          <button class="px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg font-bold hover:shadow-lg transition">
            ➕ Tambah Staff Baru
          </button>

          <!-- Staff Grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div v-for="staff in staffList" :key="staff.id" class="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition">
              <div class="flex items-center justify-between mb-4">
                <div>
                  <p class="text-2xl">{{ staff.emoji }}</p>
                </div>
                <span :class="['px-3 py-1 rounded-full text-xs font-bold', staff.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700']">
                  {{ staff.status === 'active' ? '🟢 Online' : '⚫ Offline' }}
                </span>
              </div>
              <p class="text-xl font-bold text-amber-900">{{ staff.name }}</p>
              <p class="text-sm text-gray-600 mb-4">{{ staff.role }}</p>
              <div class="space-y-2 text-sm text-gray-600 mb-4">
                <p>📧 {{ staff.email }}</p>
                <p>📞 {{ staff.phone }}</p>
                <p>📍 Join: {{ staff.joinDate }}</p>
              </div>
              <div class="flex gap-2">
                <button class="flex-1 px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition text-sm font-bold">Edit</button>
                <button class="flex-1 px-3 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition text-sm font-bold">Hapus</button>
              </div>
            </div>
          </div>
        </div>
      </template>

      <!-- Analytics Tab -->
      <template v-if="activeTab === 'analytics'">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <!-- Weekly Chart -->
          <div class="bg-white rounded-2xl p-8 shadow-md">
            <h2 class="text-2xl font-bold text-amber-900 mb-6">📈 Penjualan Mingguan</h2>
            <div class="space-y-4">
              <div v-for="day in weeklyData" :key="day.day" class="flex items-center gap-4">
                <span class="w-16 text-sm font-bold text-gray-600">{{ day.day }}</span>
                <div class="flex-1 h-8 bg-gray-200 rounded-lg overflow-hidden">
                  <div class="h-full bg-gradient-to-r from-amber-600 to-orange-600" :style="{ width: (day.sales / 2000000) * 100 + '%' }"></div>
                </div>
                <span class="text-sm font-bold text-orange-600 min-w-32 text-right">
                  Rp {{ day.sales.toLocaleString('id-ID') }}
                </span>
              </div>
            </div>
          </div>

          <!-- Category Distribution -->
          <div class="bg-white rounded-2xl p-8 shadow-md">
            <h2 class="text-2xl font-bold text-amber-900 mb-6">📊 Kategori Terlaris</h2>
            <div class="space-y-4">
              <div v-for="cat in categoryData" :key="cat.name" class="p-4 bg-gradient-to-r rounded-lg text-white" :style="{ backgroundImage: `linear-gradient(135deg, ${cat.color1}, ${cat.color2})` }">
                <div class="flex justify-between items-center">
                  <div>
                    <p class="font-bold text-lg">{{ cat.name }}</p>
                    <p class="text-sm opacity-90">{{ cat.items }} items</p>
                  </div>
                  <div class="text-right">
                    <p class="font-bold text-2xl">{{ cat.percent }}%</p>
                    <p class="text-xs opacity-90">Rp {{ cat.sales.toLocaleString('id-ID') }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../store/auth.js'

const router = useRouter()
const authStore = useAuthStore()

const activeTab = ref('overview')

const todayProfit = ref(2850000)
const totalOrders = ref(28)
const avgOrderValue = computed(() => 165000)

const recentOrders = ref([
  { id: 1005, table: 'A-03', items: 2, amount: 75000, time: new Date(Date.now() - 3 * 60000) },
  { id: 1004, table: 'C-01', items: 2, amount: 55000, time: new Date(Date.now() - 8 * 60000) },
  { id: 1003, table: 'A-01', items: 2, amount: 45000, time: new Date(Date.now() - 15 * 60000) },
  { id: 1002, table: 'B-01', items: 3, amount: 65000, time: new Date(Date.now() - 22 * 60000) },
  { id: 1001, table: 'A-02', items: 3, amount: 80000, time: new Date(Date.now() - 28 * 60000) },
])

const topItems = ref([
  { name: 'Mie Kuah Spesial', sold: 156 },
  { name: 'Nasi Kuning', sold: 134 },
  { name: 'Sup Ayam', sold: 98 },
  { name: 'Spaghetti Carbonara', sold: 87 },
  { name: 'Jeruk Segar', sold: 76 },
])

const menuItems = ref([
  { id: 1, name: 'Mie Kuah Spesial', price: 35000, category: 'Mie & Pasta', stock: 45, active: true },
  { id: 2, name: 'Nasi Kuning', price: 30000, category: 'Nasi', stock: 28, active: true },
  { id: 3, name: 'Sup Ayam', price: 40000, category: 'Soup', stock: 12, active: true },
  { id: 4, name: 'Kopi Spesial', price: 15000, category: 'Minuman', stock: 8, active: false },
  { id: 5, name: 'Gorengan Tahu', price: 15000, category: 'Makanan Ringan', stock: 52, active: true },
])

const staffList = ref([
  { id: 1, name: 'Budi Santoso', role: 'Waiter', emoji: '👨‍🍳', email: 'budi@localbowls.com', phone: '081234567890', joinDate: '15 Jan 2024', status: 'active' },
  { id: 2, name: 'Siti Nurhaliza', role: 'Kitchen Staff', emoji: '👩‍🍳', email: 'siti@localbowls.com', phone: '082234567891', joinDate: '10 Jan 2024', status: 'active' },
  { id: 3, name: 'Ahmad Rizki', role: 'Cashier', emoji: '👨‍💼', email: 'ahmad@localbowls.com', phone: '083234567892', joinDate: '20 Jan 2024', status: 'active' },
  { id: 4, name: 'Rina Putri', role: 'Waiter', emoji: '👩‍🍳', email: 'rina@localbowls.com', phone: '084234567893', joinDate: '08 Jan 2024', status: 'active' },
  { id: 5, name: 'Doni Hermawan', role: 'Kitchen Staff', emoji: '👨‍🍳', email: 'doni@localbowls.com', phone: '085234567894', joinDate: '12 Jan 2024', status: 'active' },
  { id: 6, name: 'Lisa Handoko', role: 'Admin', emoji: '👩‍💼', email: 'lisa@localbowls.com', phone: '086234567895', joinDate: '01 Jan 2024', status: 'active' },
])

const weeklyData = ref([
  { day: 'Senin', sales: 1250000 },
  { day: 'Selasa', sales: 1450000 },
  { day: 'Rabu', sales: 1680000 },
  { day: 'Kamis', sales: 1920000 },
  { day: 'Jumat', sales: 2100000 },
  { day: 'Sabtu', sales: 1850000 },
  { day: 'Minggu', sales: 2850000 },
])

const categoryData = ref([
  { name: 'Mie & Pasta', items: 3, sales: 850000, percent: 28, color1: '#FF6B6B', color2: '#FFA500' },
  { name: 'Nasi', items: 3, sales: 720000, percent: 25, color1: '#4ECDC4', color2: '#44A08D' },
  { name: 'Soup', items: 3, sales: 580000, percent: 19, color1: '#95E1D3', color2: '#38B6A8' },
  { name: 'Minuman', items: 3, sales: 420000, percent: 14, color1: '#FFDAB9', color2: '#FFB347' },
  { name: 'Makanan Ringan', items: 3, sales: 280000, percent: 14, color1: '#DDA15E', color2: '#BC6C25' },
])

const formatTime = (date) => {
  return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
}

const logout = () => {
  authStore.logout()
  router.push('/login')
}

onMounted(() => {
  if (!authStore.isAuthenticated || authStore.user?.role !== 'admin') {
    router.push('/login')
  }
})
</script>