// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api'

class ApiService {
  constructor(baseURL = API_BASE_URL) {
    this.baseURL = baseURL
  }

  // Helper method untuk add authorization header
  getHeaders() {
    const token = localStorage.getItem('authToken')
    return {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` })
    }
  }

  // Helper method untuk image URL
  getImageUrl(imagePath) {
    if (!imagePath) return '/placeholder.png'
    if (imagePath.startsWith('http')) return imagePath
    return `${this.baseURL.replace('/api', '')}/images${imagePath.startsWith('/') ? imagePath : '/' + imagePath}`
  }

  // GET request
  async get(endpoint) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'GET',
        headers: this.getHeaders()
      })
      return await this.handleResponse(response)
    } catch (error) {
      throw this.handleError(error)
    }
  }

  // POST request
  async post(endpoint, data) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(data)
      })
      return await this.handleResponse(response)
    } catch (error) {
      throw this.handleError(error)
    }
  }

  // PUT request
  async put(endpoint, data) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'PUT',
        headers: this.getHeaders(),
        body: JSON.stringify(data)
      })
      return await this.handleResponse(response)
    } catch (error) {
      throw this.handleError(error)
    }
  }

  // DELETE request
  async delete(endpoint) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'DELETE',
        headers: this.getHeaders()
      })
      return await this.handleResponse(response)
    } catch (error) {
      throw this.handleError(error)
    }
  }

  // Handle response
  async handleResponse(response) {
    if (!response.ok) {
      const error = await response.json().catch(() => ({}))
      throw new Error(error.message || `HTTP ${response.status}`)
    }
    return await response.json()
  }

  // Handle error
  handleError(error) {
    console.error('API Error:', error)
    return error
  }

  // ===== MENU ENDPOINTS =====
  getMenu() {
    return this.get('/menu')
  }

  getMenuById(id) {
    return this.get(`/menu/${id}`)
  }

  // ===== ORDER ENDPOINTS =====
  placeOrder(orderData) {
    return this.post('/orders', orderData)
  }

  getOrder(orderId) {
    return this.get(`/orders/${orderId}`)
  }

  getOrderStatus(orderId) {
    return this.get(`/orders/${orderId}/status`)
  }

  updateOrderStatus(orderId, status) {
    return this.put(`/orders/${orderId}/status`, { status })
  }

  // ===== STAFF ENDPOINTS =====
  getStaffOrders(role) {
    return this.get(`/staff/orders?role=${role}`)
  }

  updateOrderProgress(orderId, progress) {
    return this.put(`/orders/${orderId}/progress`, { progress })
  }

  completeOrder(orderId) {
    return this.put(`/orders/${orderId}/complete`, {})
  }

  // ===== PAYMENT ENDPOINTS =====
  processPayment(paymentData) {
    return this.post('/payments', paymentData)
  }

  getPaymentStatus(transactionId) {
    return this.get(`/payments/${transactionId}`)
  }

  // ===== STATISTICS ENDPOINTS =====
  getDailyStats() {
    return this.get('/stats/daily')
  }

  getMonthlyStats() {
    return this.get('/stats/monthly')
  }

  getTotalRevenue() {
    return this.get('/stats/revenue')
  }
}

export default new ApiService()