import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

// Demo credentials untuk testing
const DEMO_USERS = {
  'waiter@localbowls': { password: 'pass123', role: 'waiter', name: 'Waiter Team' },
  'kitchen@localbowls': { password: 'pass123', role: 'kitchen', name: 'Kitchen Team' },
  'cashier@localbowls': { password: 'pass123', role: 'cashier', name: 'Cashier Team' },
  'admin@localbowls': { password: 'pass123', role: 'admin', name: 'Admin' }
}

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const token = ref(localStorage.getItem('authToken'))
  const rememberMe = ref(localStorage.getItem('rememberMe') === 'true')

  const isAuthenticated = computed(() => !!token.value && !!user.value)

  const login = async (email, password, remember = false) => {
    try {
      // Demo login - untuk production ganti dengan API call
      const demoUser = DEMO_USERS[email]
      
      if (!demoUser || demoUser.password !== password) {
        throw new Error('Email atau password salah')
      }

      user.value = {
        email,
        role: demoUser.role,
        name: demoUser.name
      }
      
      token.value = 'demo-token-' + Date.now()
      rememberMe.value = remember

      // Save to localStorage
      localStorage.setItem('authToken', token.value)
      localStorage.setItem('user', JSON.stringify(user.value))
      localStorage.setItem('rememberMe', remember)

      return user.value
    } catch (error) {
      throw error
    }
  }

  const logout = () => {
    user.value = null
    token.value = null
    rememberMe.value = false
    
    localStorage.removeItem('authToken')
    localStorage.removeItem('user')
    localStorage.removeItem('rememberMe')
  }

  const restoreSession = () => {
    if (token.value && rememberMe.value) {
      const savedUser = localStorage.getItem('user')
      if (savedUser) {
        user.value = JSON.parse(savedUser)
      }
    }
  }

  // Load from localStorage on init
  const savedUser = localStorage.getItem('user')
  if (savedUser && token.value) {
    try {
      user.value = JSON.parse(savedUser)
    } catch (e) {
      console.error('Failed to restore user session:', e)
    }
  }

  return {
    user,
    token,
    rememberMe,
    isAuthenticated,
    login,
    logout,
    restoreSession
  }
})