import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useCartStore = defineStore('cart', () => {
  const items = ref([])
  const customerInfo = ref({
    name: '',
    phone: '',
    table: '',
    notes: ''
  })

  // Total price
  const total = computed(() => {
    return items.value.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  })

  // Total items count
  const itemCount = computed(() => {
    return items.value.reduce((sum, item) => sum + item.quantity, 0)
  })

  // Add item to cart
  const addItem = (item) => {
    const existingItem = items.value.find(i => i.id === item.id)
    
    if (existingItem) {
      existingItem.quantity += item.quantity || 1
    } else {
      items.value.push({
        ...item,
        quantity: item.quantity || 1,
        cartItemId: Date.now() // Unique ID untuk cart item
      })
    }
  }

  // Remove item from cart
  const removeItem = (cartItemId) => {
    items.value = items.value.filter(i => i.cartItemId !== cartItemId)
  }

  // Update item quantity
  const updateQuantity = (cartItemId, quantity) => {
    const item = items.value.find(i => i.cartItemId === cartItemId)
    if (item) {
      if (quantity <= 0) {
        removeItem(cartItemId)
      } else {
        item.quantity = quantity
      }
    }
  }

  // Clear cart
  const clearCart = () => {
    items.value = []
  }

  // Set customer info
  const setCustomerInfo = (info) => {
    customerInfo.value = { ...customerInfo.value, ...info }
  }

  // Place order
  const placeOrder = async () => {
    // TODO: Call API to place order
    return {
      orderId: Math.floor(Math.random() * 100000),
      items: items.value,
      total: total.value,
      customerInfo: customerInfo.value,
      timestamp: new Date()
    }
  }

  return {
    items,
    customerInfo,
    total,
    itemCount,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    setCustomerInfo,
    placeOrder
  }
})